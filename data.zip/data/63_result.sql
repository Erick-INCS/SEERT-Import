INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '52459708',
      'EMPUJADOR INFERIOR',
      'EMPUJADOR INFERIOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1411',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1632',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1683',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1692',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1913',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-802',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-862',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502919327-818',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502919327-861',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503062576-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503936826-100',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503941627-100',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-235',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B40140-794 SHT2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B:ASSM PER FIG F',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '71791965',
      'SENSOR PARA CILINDRO',
      'SENSOR PARA CILINDRO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84129001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75-3896 DRW 000 08',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE179 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE244 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WF165 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WG150 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE195 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WS188 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800L-18L24BB',
      'BOTON PARA INTERRUPTOR',
      'BOTON PARA INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85318099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-1TW-40439 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-1TYM T',
      'INTERRUPTOR',
      'INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800TC-A1A2 T',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '8222-41228601-LSI-7551',
      'INSERTADORA  DE  COMPONENTES ',
      'INSERTADORA  DE  COMPONENTES ',
      'ACT',
      'Maquinaria',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94563691',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'AF-2269',
      'PLACA CONFORMADA DE ALUMINIO',
      'PLACA CONFORMADA DE ALUMINIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '76169999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BA002073',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BTRY-TC8X-67MA1-01',
      'SELLOS',
      'SELLOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85076001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'COTO WABASH RELAYS',
      'RELEVADORES',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6B40113-20',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6Y-159088',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'F752',
      'NUCLEO MAGNETICO',
      'NUCLEO MAGNETICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85051101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'GT-CANB00-A-0000',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'H921',
      'TRANSDUCTOR DE CORRIENTE',
      'TRANSDUCTOR DE CORRIENTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90303399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'HBL4550',
      'TOMAS DE CORRIENTE',
      'TOMAS DE CORRIENTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85366902',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'KIT TOOLS',
      'JUEGO DE HERRAMIENTAS',
      'JUEGO DE HERRAMIENTAS',
      'MAT',
      'Materias Primas',
      'SET',
      'PCS',
      '82055999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'O-56921-606',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'O-60086',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P101622',
      'AGUJAS PARA CONECTOR',
      'AGUJAS PARA CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P335912',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PC8189',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110183',
      'TERMINALES',
      'TERMINALES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110350',
      'PROVIENE DE BOM',
      'VPL-MOTOR,PAINT,BLACK,PHANTOM',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-115392',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-126869(2 SHTS OF 12"EA)',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-127150',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-133778',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-135609',
      'CAJA PLASTICA DE PROTECCION',
      'ETO: MINI COM SURFACE MOUNT BOX',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-152545-65345446',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-152586',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-175907',
      'INTERRUPTOR DESENSAMBLADO',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-177933',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-184498',
      'PROVIENE DE BOM',
      'P/C T,94267701',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-184570',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-184711',
      'VENTILADOR',
      'VENTILADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84145999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-189632',
      'PROVIENE DE BOM',
      'VPS-B1653D,ASM,TUBE-CABLE,5M',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-193523',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-196253-65349842',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-219808',
      'PROVIENE DE BOM',
      'PBL,VPL,MOTOR,MANUAL,INSTALL INSTRUCTION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-234759',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-243688',
      'PROVIENE DE BOM',
      'PKG ASSY,TK-RPCXX1/A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-24567',
      'PROVIENE DE BOM',
      'M35 STATUS ONLY-SAFETY-DOL D 24VDC',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-249639',
      'PROVIENE DE BOM',
      '2100 STAB ASSY,225A, 140G-J VERT w/o EFT',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-249959',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-263069',
      'PANEL (TERMINAL) DE CONTROL',
      'PANELVIEW 800 7-INCH HMI TERMINAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-274366',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-292263',
      'RIEL PARA GABINETE DE DISTRIBUCION DE ELECTRICIDAD',
      'RIEL PARA GABINETE DE DISTRIBUCION DE ELECTRICIDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-311839',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-320316',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-341831',
      'TERMINALES',
      'TERMINALES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-364849',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-37765-65349164',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-386282',
      'CIRCUITO INTEGRADO',
      'CIRCUITO INTEGRADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85423999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-390327',
      'APARATO PARA COMUNICACION EN RED',
      'APARATO PARA COMUNICACION EN RED',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85176299',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-39514',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-441852',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-449025',
      'CABLE ELECTRICO SIN CONECCIONES',
      'ETO: 22/3 AWM 2517 105C 300V Unshielded',
      'MAT',
      'Materias Primas',
      'MT',
      'KG',
      '85444904',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-467082',
      'MARCO GUIA DE CABLES PARA CAJAS DE DISTRIBUCION ELECTRICA',
      'MARCO GUIA DE CABLES PARA CAJAS DE DISTRIBUCION ELECTRICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-476161',
      'INTERRUPTOR ELECTRICO',
      'INTERRUPTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-48056',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-482785',
      'CABLE ELECTRICO',
      'CABLE ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-485040',
      'ARRANCADOR INVERSOR',
      'ARRANCADOR INVERSOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-487658',
      'CONTACTO PARA RELEVADOR',
      'CONTACTO PARA RELEVADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-497960',
      'SOPORTE DE ACERO',
      'SOPORTE DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-498490',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-515695',
      'RESISTENCIAS',
      'RESISTENCIAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-527653',
      'CONTROLADOR DE VELOCIDAD',
      'CONTROLADOR DE VELOCIDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-530738',
      'CIRCUITO IMPRESO',
      'CIRCUITO IMPRESO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-546741',
      'DISYUNTOR',
      'DISYUNTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-546813',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-54693',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-56805',
      'CONTROL DE TEMPERATURA Y HUMEDAD',
      'CONTROL DE TEMPERATURA Y HUMEDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90328999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-571108',
      'RESISTORES',
      'RESISTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-57574',
      'CONTACTOS',
      'CONTACTOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '76020001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-584886',
      'CIRCUITO IMPRESO',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-586104',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-601213',
      'TORNILLOS',
      'TORNILLOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181510',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-65505',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67487-65352074',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-71526-65343418',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-81063',
      'ETIQUETA DE PLASTICO AUTOADHESIVA',
      'DANGER LBL,PLYSTR,2.0"X4.0",',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39199099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-83833',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-89696',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-94159',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34080',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34202',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C35545',
      'NUMEROS DE PLASTICO',
      'NUMEROS DE PLASTICO',
      'MAT',
      'Materias Primas',
      'CJS',
      'KG',
      '39269013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C63665',
      'SUBPANEL GALVANIZADO',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94314-65756612',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94919 -65678097',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D10249',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D10641',
      'PROVIENE DE BOM',
      'STRTR,SZ3,W/OLR PROVISION,120V,60HZ',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D165967',
      'PROVIENE DE BOM',
      'ERICO 6 x 24 x 1 - 42"',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D166304',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167424',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170483',
      'PROVIENE DE BOM',
      'VPC-2154A,S/A,STATOR,Kexx',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D177168',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002972',
      'PROVIENE DE BOM',
      'ETO: L2 LUG PAD FOR 140G-K FRAME 400A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E007631',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E015779',
      'PROVIENE DE BOM',
      'ETO: MTG PLATE MOD FOR GRD FAULT MONITOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E016391',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E019449',
      'PROVIENE DE BOM',
      'ETO: MEDIUM GUARD FOR 1200A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E020495',
      'PROVIENE DE BOM',
      'ETO: L3 LOAD VERTICAL BUS BAR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E032127',
      'BARRA DE CONDUCCION',
      'BARRA DE CONDUCCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E032492',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E036699',
      'SOPORTE DE ACERO',
      'SOPORTE DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E073172',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-F001729',
      'CONECTOR DE ACERO ZINCADO',
      'CONECTOR DE ACERO ZINCADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73079903',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'RJHSE5E80',
      'MODULO DE INTERFACE',
      'MODULO DE INTERFACE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'ROCKS3-KIT2-NDS A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Ref Assy 100006652',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SC ASSEMBLY INST 1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'VPH-1003',
      'MANGAS DE ACERO',
      'MANGAS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'c6f4b448727bba044a3689ac73c826',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'd23dd0bf6eed700199abbf2b0b3450',
      'MAQUINA   PROBADORA   DE   CIRCUITOS',
      'MAQUINA   PROBADORA   DE   CIRCUITOS',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '050-PRP2503H',
      'PUNTILLA PARA PROBADOR DE CIRCUITOS',
      'PUNTILLA PARA PROBADOR DE CIRCUITOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '90309099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '0ba39fc49a773728ed5f23598c373b',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000245156',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000678288 SH10',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001111442 SH8',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001259490-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001587948-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001602419-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001622920-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001628317-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001688843-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001700973-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002291388-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10003365266-1',
      'CUBIERTA PARA MOTOR ELECTRICO',
      'CUBIERTA PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005441902-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005483072-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005575188-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005629750-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005697809-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005702317-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-AWDJ2-Q2575 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10521971',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10603724',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10608406',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10648004',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10669014',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10669048',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10705780',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '107S-ASDJ3-CB40D A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '107S-ATDJ3-CB10C A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10800400',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10806813',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '143526',
      'BANDA DE PLASTICO',
      'BANDA DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269002',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE050L A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE060F A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CS010C A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1497-D-HXDX-0-N A',
      'TRANSFORMADOR',
      'TRANSFORMADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85043199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '194RC-NJ060M4 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '20',
      'SISTEMA AUTOMATICO DE CORTE DE PANELES  ( ROUTER- 3)',
      'SISTEMA AUTOMATICO DE CORTE DE PANELES  ( ROUTER- 3)',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '84862099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '203169-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '21-301-538-03',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '21-301-634-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '23157-124-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '2711E-UK12EK10 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '280D-S12D-10B-CR C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '281D-S12Z-10B-CR C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30018-013-05',
      'PUERTA PARA PANEL',
      'PUERTA PARA PANEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30020-001-02',
      'PROVIENE DE BOM',
      'ETO: UNIT SUPPORT PAN MOD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30100-382-15',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-065-05',
      'PROVIENE DE BOM',
      'XFMR MTG PLT MOD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30114-566-01',
      'PROVIENE DE BOM',
      'MINI CNTROL STA MOD',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30115-166-01',
      'PROVIENE DE BOM',
      'ETO:TOP LEFT HAND BAFFLE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30126-826-02',
      'PROVIENE DE BOM',
      'ETO: TRAY 4 FAN RITTAL TS8 800W',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30139-108-01',
      'PROVIENE DE BOM',
      '20" x 30" PANEL XFMR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30183-139-01',
      'PROVIENE DE BOM',
      'ETO:FUSE BARRIER',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31275-190-12',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '313324',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '32018-043-02',
      'SOPORTE DE MONTAJE',
      'SOPORTE DE MONTAJE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83024999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '375841-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '3a727786d840e4846ac47fc9298a0f',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40112-888-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-015-01G',
      'PROVIENE DE BOM',
      'GRD BUS LINK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-947-14',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40140-402',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40140-946',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40185-119-57',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40185-464-11',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40194-330-51',
      'PROVIENE DE BOM',
      '4-PIN S/S 22.5MM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40266-594-04',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40405-456-02-E278',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-500-17',
      'PROVIENE DE BOM',
      'E3 OVERLOAD ASSEMBLY',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-451-10-D1BZ',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-492-08-S1FX',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '445-9084-1-ND',
      'CAPACITORES DE CERAMICA',
      'CAPACITORES DE CERAMICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '445L-P4S1560YD',
      'DISPOSITIVO FOTOSENSIBLE',
      'DISPOSITIVO FOTOSENSIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-DOB-A1K E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '510160124',
      'CARCAZA PARA CONECTOR',
      'CARCAZA PARA CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DABD-B1K-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DDB-O5104 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DFB-M6392 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '55-11-224',
      'EMPAQUE DE HULE',
      'EMPAQUE DE HULE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '40169399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '58545-1',
      'UTIL PARA PUNZONAR',
      'UTIL PARA PUNZONAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82073001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '63-I50R-705-B',
      'ENGRANE PARA FLECHA',
      'ENGRANE PARA FLECHA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84839099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1036',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1039',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1276',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1318',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1642',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1660',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2222',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-383',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-646',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-733',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-842',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-845',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503152326-2200',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503152326-2700',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-173',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504399292',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '69.710.1358',
      'MONITOR PARA COMPUTADORA',
      'MONITOR PARA COMPUTADORA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85285902',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6ASSEMBLE PER FIG G',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6RRH0',
      'SELLADOR',
      'SELLADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '32149099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6d761f802893d69e44fe2cdbdf16bf',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-2012',
      'CAPACITORES DE TANTALIO',
      'CAPACITORES DE TANTALIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7000360829-10',
      'RESORTES HELICOIDALES',
      'RESORTES HELICOIDALES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73202001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75028-404 DRW 000 03',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '77159-612-14',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '77163-610-04',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7781629',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WS208 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE208 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800H-PRT16C F',
      'LUZ INDICADORA',
      '30mm Pilot Light 800H PB',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85318099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94525901',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '98-20171',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'C16202A0011',
      'FUENTE DE PODER',
      'FUENTE DE PODER',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'D7-17WE175 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DS9090EVKIT',
      'PROGRAMADOR PARA TRANSFERIR DATOS, CON ACCESORIOS.',
      'PROGRAMADOR PARA TRANSFERIR DATOS, CON ACCESORIOS.',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84718003',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'ENAMEL PAINT MARKER',
      'MARCADOR',
      'MARCADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '96082001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'FITC1811C-003N',
      'CABLES ELECTRICOS',
      'CABLES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444904',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'ID-0000061090',
      'LLAVE DE BOCA AJUSTABLE',
      'LLAVE DE BOCA AJUSTABLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-CBK-46',
      'PROVIENE DE BOM',
      'MCC2100 Circuit Breaker',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-98',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EBLK-2',
      'PROVIENE DE BOM',
      'MCC2100 Empty Block',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EHA-11',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EHA-3',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-FDOOR-8',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PUNIT-5',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P335902',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-104877',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110254',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-114639',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-118029',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-119297',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-14138',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-15110',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-160650',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-180558',
      'FUSIBLE',
      'FUSIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85361099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-189052',
      'ETIQUETAS',
      'ETIQUETAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '48219099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-202605-65348643',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-217750',
      'CABLE TRENZADO',
      'CABLE TRENZADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73121009',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-225039',
      'CABLE ELECTRICO SIN CONECCIONES',
      'CABLE ELECTRICO SIN CONECCIONES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-241620',
      'PROVIENE DE BOM',
      '193 E300 sen mod IEC DIN/pan -T I 60A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-258728',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-283492',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-309825',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-312908',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-317440',
      'FUSIBLES',
      'Disconnect Kits',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85361099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-321480',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-324637',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-333584',
      'PROVIENE DE BOM',
      'FM ASSY Programmed MCU_42EF Refresh TB-R',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-339428',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-348796',
      'DISYUNTOR',
      'DISYUNTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-350284',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-397206',
      'GABINETE METALICO DE PARED',
      'GABINETE METALICO DE PARED',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-411189',
      'DISYUNTORES',
      'ETO: Circuit Breaker 24V 4A',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-417334',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-453750',
      'CABLE ELECTRICO SIN CONEXION',
      'ETO: Blue/White 4 AWG THHN',
      'MAT',
      'Materias Primas',
      'MT',
      'MT',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-472740',
      'PANEL DE CONTROL',
      'PANEL DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-481998',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-493596',
      'CABLE',
      'CABLE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-528009',
      'APARATO MEDIDOR DE ENERGIA',
      'APARATO MEDIDOR DE ENERGIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90303399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-53587',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-546638',
      'RELEVADOR',
      'RELEVADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-547186',
      'ETIQUETAS',
      'ETIQUETAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39199099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-54989',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-576745',
      'PANEL PARA GABINETE',
      'PANEL PARA GABINETE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-64269',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67487-65333885',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-74738',
      'CUBIERTA PARA LUZ INDICADORA',
      'CUBIERTA PARA LUZ INDICADORA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85319099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-97685',
      'PROTECTOR PLASTICO PARA CABLES',
      'WIRE DUCT, 2X5, GRAY, 6FT',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-98010',
      'SOPORTE DE MONTAJE CON ACCESORIOS',
      'SOPORTE DE MONTAJE CON ACCESORIOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C134576-65736659',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C33506',
      'GABINETE SIN SUS APARATOS',
      'GABINETE SIN SUS APARATOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34105',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34220',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C95808',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'PowerFlex 700 AC Drive 34 A at 25 Hp 20B',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D10177',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167365',
      'PROVIENE DE BOM',
      'MCCB 140G-H 100kA/480V AA 125A 3p  w/Aux',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167626',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170424',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170485',
      'PROVIENE DE BOM',
      'VPC-2155D,S/A,STATOR,Kexx',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E000955',
      'PROVIENE DE BOM',
      'ETO: .125 THK POLYCARBONATE WINDOW',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002646',
      'PROVIENE DE BOM',
      'ETO: L2 INSIDE LINK FOR 1600A "RD" BRKR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002848',
      'PROVIENE DE BOM',
      'ETO: CONTROL STATION 2-BUTTON COVER MOD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002953',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E004781',
      'PROVIENE DE BOM',
      'ETO: PLATE,SUPPORT,FEEDER',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E015641',
      'PROVIENE DE BOM',
      'ETO: 35 IN  WIDE REACTOR MTG PLT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E016775',
      'PROVIENE DE BOM',
      'ETO: L2 LINE LUG PAD OUTSIDE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E032132',
      'BARRA DE CONDUCCION',
      'BARRA DE CONDUCCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E032968',
      'CONDUCTORES ELECTRICOS',
      'CONDUCTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E073872',
      'SOPORTE DE ACERO',
      'SOPORTE DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E078607',
      'ETIQUETAS',
      'ETIQUETAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '48211001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-F000093',
      'CERROJO',
      'CERROJO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '83014001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'QTP-03902',
      'PERNOS DE ACERO',
      'PERNOS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'RIVET GUN',
      'REMACHADORA MANUAL',
      'REMACHADORA MANUAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82055912',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'RTV 738',
      'SILICONA PARA EMPLEO ELECTRONICO',
      'SILICONA PARA EMPLEO ELECTRONICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39100001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SL21-04-I06-QC',
      'DESTORNILLADOR ELECTRICO DE USO MANUAL',
      'DESTORNILLADOR ELECTRICO DE USO MANUAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84672999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TRANSMITTER CABLE',
      'CABLE CON CONECTORES',
      'CABLE CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '49119999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'f5c441eb78e16eeb40edda8eac9661',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'pn-212215',
      'DISYUNTORES',
      '2100 140G K FRAME C.B., BAIL ASSY',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '0002-1734-65333861',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '07/08/2788',
      'PROVIENE DE BOM',
      'PSEUDOS,PCB MTG KIT, MAIN CONTROL, PHASE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '08e34be4945cfc699f97eecb788b83',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '100-C37L00C',
      'CONTACTOR',
      'CONTACTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001587170-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001671871-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001671885-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001671908-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001676543-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001696861-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001760315-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001791043-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001824565-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002454049-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002708975-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002928324 SH15',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005298074-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005538744-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005591809-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005609795-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005630474-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005632370-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005669662-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005696030-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '102426',
      'CIRCUITOS IMPRESOS',
      'CIRCUITOS IMPRESOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10495693',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10541920',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10545064',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10659214',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10682235',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10697850',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10709359',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10713252',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10713367',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10830630',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '123237',
      'CUCHILLAS',
      'CUCHILLAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1233X-DNB-6PC-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE020VB A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CAB025X62 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-FB1J30-L B',
      'PORTAFUSIBLE',
      '1 Pole Fuse Holder',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB050WA A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB060UB A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1494V-DJX61-S90523',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1756-EN2TR',
      'PUENTE MODULO PARA INTERNET',
      'PUENTE MODULO PARA INTERNET',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85176299',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1821892',
      'CUBIERTA PARA MOTOR ELECTRICO',
      'CUBIERTA PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '190S-ANDJ2-L3841 B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '190S-ANDJ2-Q3006 B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '195505-Q16',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '20G14ND361AN0NNNNN',
      'CONTROLADORES DE VELOCIDAD
',
      'CONTROLADORES DE VELOCIDAD
',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269003',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '2100-TD019.-EN-P',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '23PC41',
      'TERMINAL PARA BATERIA',
      'TERMINAL PARA BATERIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '263e541d2df45a24cf35403b62108e',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30042-279-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30100-378-13',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-198-08',
      'PROVIENE DE BOM',
      'ETO: HORZ WW COVER MOD, 30W',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-249-60',
      'PROVIENE DE BOM',
      'MOD CONTROL STATION',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30125-568-02',
      'PROVIENE DE BOM',
      'MTG BRKT FOR XFMR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30132-866-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30155-306-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30165-676-01',
      'BARRA DE BUSES',
      'ETO: BUS, OFFSET SPLICE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30186-321-01',
      'PROVIENE DE BOM',
      'BARRIER',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30201-063-02,NC=DS',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30342-146-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31275-190-10',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '332165-F04',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '348883-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40.808.1566',
      'CEPILLO',
      'CEPILLO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40113-305-35',
      'PROVIENE DE BOM',
      '600A VERT BUS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40113-892-18',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40119-194-11',
      'PROVIENE DE BOM',
      '40119 DOOR ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40122-036-04',
      'PROVIENE DE BOM',
      'BOT CLOSING PLT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40137-566-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40140-452 SHT 1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40266-472-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40359-488-17',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40410-123-03',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-365-93',
      'PROVIENE DE BOM',
      'HEAT SINK DRIVE ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40888-823 SWR 000 09',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41164-217-56',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-451-10-S1FZ',
      'PROVIENE DE BOM',
      'SMC FLEX MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-459-05',
      'PROVIENE DE BOM',
      '5/85A SMC FLEX',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201862028A056A056',
      'PROVIENE DE BOM',
      '#8 AWG Cut and Stripped',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4857521',
      'MARCO METALICO
',
      'MARCO METALICO
',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84314902',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4995-0',
      'CONECTOR DESENSAMBLADO',
      'CONECTOR DESENSAMBLADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FED-1 C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '512-DCB-1-27J 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DCB-J6993 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DFB-L9679 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DFH-4LR-6P-441',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DJBD-1-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DUBD-A2K-47 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '520F-COD-A2G-A2J E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '52700401',
      'JUEGO DE REEMPLAZO PARA PESTILLO DE ALIMENTADOR',
      'JUEGO DE REEMPLAZO PARA PESTILLO DE ALIMENTADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6001659841-1',
      'PANEL SIN APARATOS',
      'PANEL SIN APARATOS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502689618-400',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1605',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-345',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-784',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502986441-800',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503884436-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-411',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504339101-824',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504339101-930',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B:40140-794 SHT 1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B:ASSY INSTR 40110-018',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-15929',
      'GRASA LUBRICANTE',
      'GRASA LUBRICANTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '34039999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7000363455-10',
      'CIRCUITO MODULAR',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389005',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '706 40111-012-03',
      'PARTES PARA GABINETE DE METAL',
      'PARTES PARA GABINETE DE METAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74102-588-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75-3167 DRW 000 09',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75033-403 DRW 000 02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7755504',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7772256',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7774326',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7792283',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WF138 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FM-LF5MN5YX11 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FP-G4MX11 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FP-LFA3P-R7497A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '855E-ASC A',
      'TORNILLOS DE ACERO',
      'Mod. Lens Securing Screws',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181504',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '90030109',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '91595A384',
      'PERNOS DE ACERO',
      'PERNOS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '92417801',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94149268',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '96182603',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '96905202',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '97394846',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '99-01046',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'A1D03130196-01',
      'PUNTA APLICADORA DE PLASTICO',
      'PUNTA APLICADORA DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'A34242CT-ND',
      'CABLE ELECTRICO CON CONEXION',
      'CABLE ELECTRICO CON CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'B-29059',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BA001707',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BA001994',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BT301006-6',
      'NUCLEO MAGNETICO',
      'NUCLEO MAGNETICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CARPENTER M77E PNEUM',
      'PELADORA DE CABLE NEUMATICA',
      'PELADORA DE CABLE NEUMATICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84798999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'D7M-LF4MN5RX10 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000674151',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'EA6180-LD',
      'BOQUILLA',
      'BOQUILLA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'JDXN77-0006-A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Jul-35',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PCNT-17',
      'PROVIENE DE BOM',
      'MCC2100  Plug-in Unit Control Station',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PCNT-70',
      'PROVIENE DE BOM',
      'MCC2100  Plug-in Unit Control Station',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PCNT-9',
      'PROVIENE DE BOM',
      'MCC2100  Plug-in Unit Control Station',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PUNIT-105',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110255',
      'PROVIENE DE BOM',
      'VPL-x1304x,S/A,HSG-STR-EC,KE141,PHANTOM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-113404',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-113412',
      'PROVIENE DE BOM',
      'POWER LAYER PCB,FR 1,5HP,400/480V',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-11984',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-135180',
      'CUBIERTA DE ACRILICO',
      'CUBIERTA DE ACRILICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-152578',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-164067',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-168212',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-172240',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-184566',
      'PROVIENE DE BOM',
      'ASM,1492,AIFM8TC3,THERMOBAR,TERMINAL BLK',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-201710',
      'CONECTOR',
      'ETO: MINI DEVICENET CONNECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-203674',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205398-65705571',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205403',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'Kinetix VP Low Inertia Servo Motor',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205523-65758263',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-209238-65351953',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
