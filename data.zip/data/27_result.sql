INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-17529',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-194572',
      'PROVIENE DE BOM',
      'ETO,1000GM,ENCL MOD,598 PUSH BUTTON,2POS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-196616',
      'PROVIENE DE BOM',
      'LBL,PROD ID,1756PA72K/C',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-201937',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205871-65758291',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-210709',
      'CABLE CON CONECTORES',
      'CABLE CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-215485-65350027',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-221606',
      'TERMISTORES',
      'TERMISTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85334002',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-226448',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-241619',
      'PROVIENE DE BOM',
      '193 E300 sen mod IEC DIN/pan -T I 30A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-241640',
      'DISYUNTOR',
      '140G 125A H Frame Molded Case Ckt-Bkr',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-248694',
      'CABLE CON CONECTORES',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-250047',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-251019',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-255909',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-262822',
      'PROVIENE DE BOM',
      'LABEL CARD 46006-313',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-279464',
      'PROVIENE DE BOM',
      'CEP9 E300 sen mod IEC DIN/pan -P IG 30A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-280522',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-293745',
      'PROVIENE DE BOM',
      'PCBA,1408 Final Assembly_BC3',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-304665',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-305281',
      'FILTRO ELECTRICO',
      'FILTRO ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85437099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-307538',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-31488',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-31493',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-339439',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-339448',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-343353-65700146',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-356239',
      'RIEL METALICO',
      'RIEL METALICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83024999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-36409',
      'PROVIENE DE BOM',
      'INSTR,INSTALL,AIR PURGE KIT,M23',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-364716',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-370431',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-389821',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-402451',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-40883',
      'PARTES PARA CONTROLADOR DE VELOCIDAD DE MOTORES ELECTRICOS',
      'ArmorStart Spare Parts',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85049099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-411520',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-411638',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-419053',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-467142',
      'RESISTENCIA',
      'RESISTENCIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-473845',
      'PANEL PARA GABINETE DE DISTRIBUCION',
      'PANEL PARA GABINETE DE DISTRIBUCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-484703',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015205',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-503349',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-517801',
      'CIRCUITOS IMPRESOS',
      'CIRCUITOS IMPRESOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-534428',
      'CERRADURA DE LLAVE',
      'CERRADURA DE LLAVE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '83014001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-54035',
      'PROVIENE DE BOM',
      'MAJOR ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-563928',
      'INTERRUPTOR',
      'INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-61104',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-65405-65353098',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-83898',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-92386',
      'PROVIENE DE BOM',
      'part,2100,mounting channel',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C134320-65690935',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C135024-6565746',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C33149',
      'SOPORTE RIEL DE METAL',
      'SOPORTE RIEL DE METAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94480',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167579',
      'PROVIENE DE BOM',
      'L1-3 STAB&amp;WIRE,110A,140G-G,H,VERT,SNGL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167641',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D174375',
      'CUBIERTA PLASTICA',
      'CUBIERTA PLASTICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E001164',
      'BARRA CONDUCTORA',
      'ETO: L3 VERT BUS BAR 2191MT 1200A',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002103',
      'PROVIENE DE BOM',
      'ETO: L2 (6) LUG PAD, RD BRKR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002701',
      'PROVIENE DE BOM',
      'ETO: L2 LOAD RISER MIDDLE 2193MB ABB',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E007777',
      'PROVIENE DE BOM',
      'ETO: SUPPORT, VERTICAL, FR7, 6" SHORTER',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E024793',
      'PROVIENE DE BOM',
      'ETO: L2 LOAD SIDE INSIDE BREAKER BAR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E029878',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E033578',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E036510',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E038937',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E077099',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PORTABLE HIDRAULIC',
      'MESA DE ELEVACION HIDRAULICA',
      'MESA DE ELEVACION HIDRAULICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84289099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PRENSA TERMICA',
      'PRENSA TERMICA',
      'PRENSA TERMICA',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Ref Assy 100004947',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TERADYNE 051-004-00',
      'CABLE ELECTRICO CON CONECCIONES',
      'CABLE ELECTRICO CON CONECCIONES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '90309002',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TN-4',
      'TUERCA DE ACERO',
      'TUERCA DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'U-00820920038606',
      'CONTROLADORES DE VELOCIDAD',
      'PowerFlex 755 AC Packaged Drive',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Z540-1-1994',
      'CALIBRADOR DE VOLTAJE DE CORRIENTE ALTERNA',
      'CALIBRADOR DE VOLTAJE DE CORRIENTE ALTERNA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90303901',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'e2191ee88147efb93c6af8298c476a',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000656548 SHT 13',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000664917 SHT 13',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001676561-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001747873-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001760303-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001791081-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002493557-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10003247821-04',
      'CAJA O BASE DE ENSAMBLE DE MOTOR ELECTRICO',
      'CAJA O BASE DE ENSAMBLE DE MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10003362112',
      'PARTES PARA MOTOR ELECTRICO',
      'PARTES PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004008184-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005575194-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005612523-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005621710-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005629438-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005654826-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656301-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005659952-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005667602-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005709063-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1000A-M/A97138 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1000A-M/A97234 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103T-ASDJ2-R7298 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10546679',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10565169',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10601178',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10619914',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10660935',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10682595',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10742645',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10804474',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10808322',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10830949',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10842630',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '120',
      'TABLERO   DE   PRUEBAS   RS00653,FORMADO   POR:    PROBADOR   DE VOLTAJE MCA. HYAMPII MODELO 5030D7 PROBADOR DIELECTRICO MCA. ASSOCIATED, PROBADOR ASS',
      'TABLERO   DE   PRUEBAS   RS00653,FORMADO   POR:    PROBADOR   DE VOLTAJE MCA. HYAMPII MODELO 5030D7 PROBADOR DIELECTRICO MCA. ASSOCIATED, PROBADOR ASS',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '90308999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '120302279',
      'CIRCUITO MODULAR',
      'CIRCUITO MODULAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389005',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1379467',
      'CAJAS DE CARTON',
      'CAJAS DE CARTON',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE040B A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE150WB A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-C005005XD2 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB085Y A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '150-F108NBDD',
      'CONTROLADOR DE DISTRIBUCION',
      'CONTROLADOR DE DISTRIBUCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '15848',
      'PLACA METALICA INDICADORA',
      'PLACA METALICA INDICADORA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83100099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '179053',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '2098DSDHV220SE',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24707-025-81',
      'RESISTENCIAS FIJAS',
      'RESISTENCIAS FIJAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '284D-SVD2P-R6683 C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-088-31',
      'PROVIENE DE BOM',
      'ETO: HORZ WIREWAY COVER MOD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-266-97',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-373-21',
      'PROVIENE DE BOM',
      'RH SIDEPLATE MOD.',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30139-233-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30142-748-02',
      'PROVIENE DE BOM',
      'ETO: BRACE ZBAR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30164-235-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30183-381-01',
      'PROVIENE DE BOM',
      'POLYCARBONATE BAFFLE, RH, FI10 MODULE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30342-256-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '307543-1',
      'HERRAMIENTA DE MANO',
      'HERRAMIENTA DE MANO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82055999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '317209-Q01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '338073-Q01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '339250-Q04',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '369187-C01',
      'BARRA DE CONDUCCION ELECTRICA',
      'BARRA DE CONDUCCION ELECTRICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '372991-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '378683-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '393869-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40101-012-64',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40111-178-10',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40111-844-03',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40113-164-08',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-949-14',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40116-438-20',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40120-885-06',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40137-546-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40187-602-08',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40359-041-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40410-014-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40414-473-03-3236',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-365-80',
      'PROVIENE DE BOM',
      'HEAT SINK DRIVE ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-468-53',
      'PROVIENE DE BOM',
      'STARTER ASSM. STND.',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-477-57',
      'PROVIENE DE BOM',
      'FINAL DRIVE ASSY. - STD.',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-477-75',
      'PROVIENE DE BOM',
      'FINAL DRIVE ASSY. - STD.',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-361-51',
      'PROVIENE DE BOM',
      '60/85 SENSING MODULE ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40857-030-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40870-900-10',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40888-523-02-B1FX',
      'PROVIENE DE BOM',
      'PRINCIPLE ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40888-824 SWR 000 06',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40891-300-51',
      'PROVIENE DE BOM',
      'SMC FLEX POWER SECTION',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40891-461-02-D1BX',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41022-316-04',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-262-56',
      'PROVIENE DE BOM',
      '317/361 AMP POWER POLE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-451-04-B2FX',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201844758B456B500',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '42454-466-02-3236',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '42KA-D2JPHC-A2',
      'FOTOINTERRUPTOR',
      'FOTOINTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '440L-P2KD144YD A',
      'DISPOSITIVO FOTOSENSIBLE',
      'DISPOSITIVO FOTOSENSIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '445 PN-197903',
      'PARTES PARA GABINETE DE METAL',
      'PARTES PARA GABINETE DE METAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '50174204',
      'CABLES CON CONECTORES',
      'CABLES CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '505-BOJ-23 C',
      'ARRANCADOR',
      'ARRANCADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-DUB-1E A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FAH-3-4R L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FJB L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '510161108',
      'MODULO DE CONTACTOS',
      'MODULO DE CONTACTOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-CJAD-42-TB12 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DDCD-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-EHC-48 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '5200234',
      'RUEDA DENTADA',
      'RUEDA DENTADA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84839002',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '523F-DJB-6P-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '52409302',
      'ALOJAMIENTO',
      'ALOJAMIENTO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6002473733-4',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1602',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1836',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1853',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-222',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2303',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2306',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-620',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-772',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503770870-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503789703-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503832718-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503840369-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-241',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503984211-200',
      'PUERTA PARA PANEL',
      'PUERTA PARA PANEL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504339101-932',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B30009-275 SHT 1A',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6c68da42be485f1b57ed437c446a4d',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7000360841-10',
      'ACCESORIO DE TUBERIA DE COBRE',
      'ACCESORIO DE TUBERIA DE COBRE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '74122001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74102-462-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74106-880-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74161357',
      'INSERTO PARA PRENSA',
      'INSERTO PARA PRENSA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84669499',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75015-415 DRW 000 03',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75048-461-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7777020',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WG107 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WS107 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FP-LF6PQ3BQ10 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FP-SB32PX21 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800H-1HW4R-41452 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800H-3HZ4 P',
      'CAJA DE PROTECCION DE ACERO',
      '30mm Push Button Enclosure 800H PB',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-J5A T',
      'INTERRUPTOR',
      'INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80161-023-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80187-713-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '81009-177-60',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '85100000000000',
      'CABLE ELECTRICO CON CONEXION',
      'CABLE ELECTRICO CON CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '96235809',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '99-01242',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CSN-424765',
      'FLECHA',
      'FLECHA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84831001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000664861',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DataNameplate_1000',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'F115 FLAT GASKET',
      'EMPAQUE DE CAUCHO',
      'EMPAQUE DE CAUCHO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '40169399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'K1361.1112',
      'CUBO INTERCAMBIABLE',
      'CUBO INTERCAMBIABLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '82042099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-CAB-8',
      'PROVIENE DE BOM',
      'MCC2100 Cabinet',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-36',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-41',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-ECABLE-73',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EHA-24',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PDOOR-43',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PUNIT-63',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MMC4-SP0001667',
      'RECUBRIMIENTO PARA CIRCUITOS IMPRESOS (BARNICES)',
      'RECUBRIMIENTO PARA CIRCUITOS IMPRESOS (BARNICES)',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '32081001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MODIFY PER SCHEMATIC',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MODULE ASSEMBLY',
      'PLACA PLASTICA',
      'PLACA PLASTICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Mfg and test instr',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P313356',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110327',
      'PROVIENE DE BOM',
      'VPL-1652,RTR-SHAFT-HUB,STEG,KEY,PHANTOM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110382',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-126252-65348714',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-127170',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-135901',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-138283',
      'PROVIENE DE BOM',
      'BUL150SD,361-520A,480V SCR AND HS ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-139825',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-185748',
      'CABLE ELECTRICO CON CONECCIONES',
      'CABLE ELECTRICO CON CONECCIONES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-202396',
      'PROVIENE DE BOM',
      'BUL150-SC* 24VDC CTRL 260A 480V PWR  ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-207890',
      'PROVIENE DE BOM',
      'PHANTOM, PACKAGING RHINO FR1 TYPE 1',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-208748',
      'DISYUNTOR',
      'DISYUNTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-215484-65332627',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-215485-65352073',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-220605',
      'PROVIENE DE BOM',
      'PACKAGING SUB ASSEMBLY SMC FLEX FRAME 4',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-223839-65344103',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-225872',
      'INTERRUPTOR DE INTERNET DE 24 PUERTOS',
      'INTERRUPTOR DE INTERNET DE 24 PUERTOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85176299',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-227871-65352071',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-250034',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-250139',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-260193',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-262854',
      'PROVIENE DE BOM',
      'LABEL CARD 46006-336',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-263570',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-268981',
      'PROVIENE DE BOM',
      'P/C S029 179274',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-300354',
      'FILTRO ELECTRICO',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85437099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-320730',
      'CAPACITOR DE CERAMICA',
      'CAPACITOR DE CERAMICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-328415',
      'SOPORTE ANGULAR',
      'SOPORTE ANGULAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-330949',
      'CABLE ELECTRICO CON CONECTOR',
      'CABLE ELECTRICO CON CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-347264',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-416357-65758309',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'KG',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-434263',
      'CARCAZA PARA CONECTORES',
      'ETO: HOUSING, 2 PIN',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-438700',
      'TORNILLO DE ACERO',
      'ETO: SCREW,SEMS#6-32 X 1/2,SS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181504',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-46443',
      'PROVIENE DE BOM',
      'S/A,HSG-STR-EC,MPM-215,8",B2154B',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-478719',
      'PROTECTOR DE PLASTICO (ARO)',
      'PROTECTOR DE PLASTICO (ARO)',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-482514',
      'RESISTOR',
      'RESISTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-489399',
      'BASE',
      'BASE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-490453',
      'PIEZA AISLANTE DE PLASTICO',
      'PIEZA AISLANTE DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-522732',
      'CERRADURA',
      'CERRADURA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '83014001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-526283',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-531500',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-540700',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-547152',
      'ARMAZON DE ACERO CON ACCS',
      'ARMAZON DE ACERO CON ACCS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-547315',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-548502',
      'BLOQUE TERMINAL',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-55739',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-56234',
      'PROVIENE DE BOM',
      'ETO: Custom Label Ford 1734* CAT NO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-582395',
      'CIRCUITOS IMPRESOS',
      'CIRCUITOS IMPRESOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-582746',
      'BASE METALICA',
      'BASE METALICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-66685',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-69534',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-74645',
      'PROVIENE DE BOM',
      'ASM, BUL.28X, AS ENET,  BASE ASSY C10',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-77252-65334171',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-78974',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-78978',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-96435',
      'ARMARIO',
      'ENCLOSURE 48"X30"X10", NEMA 4',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C166935',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'PF700S AC DRIVE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27089',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34213',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C97530',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C97555',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D10352',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170349',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002644',
      'PROVIENE DE BOM',
      'ETO: L3 INSIDE LINK FOR 1600A "RD" BRKR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002805',
      'PROVIENE DE BOM',
      'ETO: SIDE PLATE FOR 4.0 SPACE FACTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E008643',
      'PROVIENE DE BOM',
      'ETO: SPLICE COVER FOR HORIZONTAL BUS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85472099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E016690',
      'PROVIENE DE BOM',
      'ETO: HORIZ BUS 1200A FOR ABB EMAX 0.25',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E027008',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E031224',
      'BARRA DE CONEXION',
      'ETO: L1 HORIZONTAL BUS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E074240',
      'BLOQUE DE SOPORTE',
      'BLOQUE DE SOPORTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E078568',
      'GABINETE',
      'GABINETE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SSB-LSC-UNIT-13',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'U-0082091904647',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'UCSC-C240-M4SX',
      'SERVIDOR',
      'SERVIDOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84715001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'X-62484',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'X-62487',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'b730881d872a4167e849660a94f17e',
      'MAQUINA INSERTADORA DE COMPONENTES 
',
      'MAQUINA INSERTADORA DE COMPONENTES ',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'cd08192f3a016d3d83d33ac773df58',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001464972-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001679221-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001729225-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002475334-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002489633-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002559338-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004061744-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004702474',
      'DISPOSITIVO PARA LINEA DE ENSAMBLE',
      'DISPOSITIVO PARA LINEA DE ENSAMBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005304883-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005382764-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005430337-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005474733-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005502450-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005648826-D2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656522-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005734347-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10548281',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10551422',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10598760',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10608044',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10608521',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10625205',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10650593',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10656748',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10660521',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10798256',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10802062',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10835341',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-C025025XDR2 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CAB050W64 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CS025A A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB040M A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB400UB A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '173285',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '190S-ANDJ2-CB10D B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '191460-Q06-65340374',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '194691-Q05',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '194RC-NN060P6 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '195301-C01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '195370-Q69',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '210-AQBK',
      'MONITOR PARA EQUIPO CON SUS ACCESORIOS',
      'MONITOR PARA EQUIPO CON SUS ACCESORIOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85285199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '23103-314-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24705-161-01',
      'RESISTENCIA FIJA',
      'RESISTENCIA FIJA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-249-59',
      'PROVIENE DE BOM',
      'MOD CONTROL STATION',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30110-485-10',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30112-767-01',
      'PROVIENE DE BOM',
      'MOD, MOUNTING BRACKET, E3 OVERLOAD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30116-536-04',
      'PROVIENE DE BOM',
      'ETO: VENT PLATE 19.63 X 12.13',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30156-858-01',
      'PROVIENE DE BOM',
      'INCOMING LINE BUS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30157-304-01',
      'PROVIENE DE BOM',
      'ETO: Z-LINK INNER SPLICE KIT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30167-194-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30342-050-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '36-308-211-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '375758-A02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '379183',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '387309',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '390736-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40111-967-09',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40112-927-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-005-17',
      'PROVIENE DE BOM',
      '3/8"X4" 2000A TINNED COPPER',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40116-512-02',
      'INTERRUPTOR DE PRESION (PRESOSTATO)',
      'INTERRUPTOR DE PRESION (PRESOSTATO)',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90322001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40119-807-06',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40415-468-04-D322',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40435-310-59',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-365-73',
      'PROVIENE DE BOM',
      'HEAT SINK DRIVE ASSY',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201854132A050A050',
      'PROVIENE DE BOM',
      '#14 AWG, 19 STRAND BLACK WIRE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '43567902',
      'SOPORTE METALICO',
      'SOPORTE METALICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '46f2b33fcedeb35b0ef5c701e6f569',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '48e1de7885fe33f69f13b3ee0909e8',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-DAB-3 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FED-3 C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '510151105',
      'SOPORTE',
      'SOPORTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '512-DDB-26R 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '512-DSB-3-26R B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '51288118',
      'BOQUILLA',
      'BOQUILLA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84818007',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DHB-1-6P-47 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DSB-46197 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '58369924a4b2413add15b15d4b6c46',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '5aed02c1636dc29ef6f9ae31f6ec04',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1324',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1466',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1546',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1707',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1997',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-235',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-423',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-530',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-630',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-911',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-992',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503057990-800',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-244',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-483',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503982918-100',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504055989-300',
      'TEMP',
      'TEMP',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74104-366-52-65336845',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74106-305-57',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75049-534',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7776968',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WF287 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WG148 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WU230 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80144-645-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80178-621-65',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80181-058-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80300-006-60',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '81024-140-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '8715240b7d664fac7200cece19c804',
      'TORNO PARALELO UNIVERSAL 13 PLG. ',
      'TORNO PARALELO UNIVERSAL 13 PLG. ',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '87235K31',
      'BARRA DE PLASTICO',
      'BARRA DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39169099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94505101',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85423999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '97-00775',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '9946',
      'PUNTAS DE BRONCE',
      'PUNTAS DE BRONCE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '74199999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'ASSY AID 40110-018',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'B074V4CS7R',
      'PINZAS',
      'PINZAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82032099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BLADE TYPE 100MIL',
      'PERNO',
      'PERNO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BLKM06004',
      'EMPAQUE DE CAUCHO',
      'EMPAQUE DE CAUCHO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '40169399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'COMPARADOR OPTICO',
      'COMPARADOR OPTICO',
      'COMPARADOR OPTICO',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CONTROLADOR A2430027',
      'CONTROLADOR DE TORQUE INTELIGENTE #8436-1800-11',
      'ATLAS  #8436-1800-11 CONTROLADOR FP6000 LV   ',
      'ACT',
      'Maquinaria',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CSN-425643',
      'CUIERTA',
      'CUIERTA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'D7M-LF5MN7YX10 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'EA2180-LD',
      'BOQUILLA',
      'BOQUILLA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'FNQ-R-2',
      'FUSIBLES',
      'FUSIBLES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85361099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'H-5681',
      'ASIENTO GIRATORIO CON ALTURA AJUSTABLE',
      'ASIENTO GIRATORIO CON ALTURA AJUSTABLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '94013001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'HIS-ML23 STTD',
      'MONITOR INDUSTRIAL PARA MONTAJE EN PANEL',
      'MONITOR INDUSTRIAL PARA MONTAJE EN PANEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85285902',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'INSULATOR',
      'PIEZA AISLANTE',
      'PIEZA AISLANTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85472099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EHA-14',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EHA-20',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-FDOOR-12',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-FDOOR-13',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PDOOR-94',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MMCI-SP0006202',
      'PASTA PARA SOLDAR',
      'PASTA PARA SOLDAR',
      'MAT',
      'Materias Primas',
      'GRM',
      'GRM',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MP-M012112',
      'ENSAMBLE DE CUBIERTA PARA IMPRESORA (PARTES)',
      'ENSAMBLE DE CUBIERTA PARA IMPRESORA (PARTES)',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84439999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P308001',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P358210',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-107857',
      'FUSIBLE',
      'FUSIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85361099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110263',
      'PROVIENE DE BOM',
      'VPL-B1303C,S/A,HSG-STR,KE198,BRK,PHANTOM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110336',
      'PROVIENE DE BOM',
      'VPx-115,INTERNAL PARTS,STANDARD PHANTOM',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-113416',
      'PROVIENE DE BOM',
      'BUFFER-POWER LYR PCB,FR 1,5HP,400/480V',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-114417',
      'JUEGO DE HERRAJES CON ACCESORIOS',
      'JUEGO DE HERRAJES CON ACCESORIOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83024999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-119899',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-123140',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-123576',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-127101',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-138284',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-14897',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-161134',
      'INTERRUPTOR DE NAVAJAS',
      'KNIFE SWITCH 100A, 250VDC, 2-POLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365008',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-169669-65344570',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-174445',
      'PROVIENE DE BOM',
      'BUL150-SC* 260A 480V PWRSEC CTRL MOD ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-180269',
      'DIODOS',
      'DIODOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85411099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-196257-65347826',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-198564-65333002',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-198564-65350715',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-198716-65704596',
      'CONTROLADOR DE VELOCIDAD',
      'CONTROLADOR DE VELOCIDAD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-201958',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-203178',
      'PROVIENE DE BOM',
      'PCBA, 30A Sensor Interface CT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-209481',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-214566',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-219957',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-246607',
      'PROVIENE DE BOM',
      'FM Assembly, Programmed IC CY8C4245PVI',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-26987',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-312369',
      'CABLE ELECTRICO CON CONECCIONES',
      'CABLE ELECTRICO CON CONECCIONES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-316055',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-328466',
      'PROVIENE DE BOM',
      'INC LINE BAFFLE ETHERNET',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-358495',
      'CIRCUITO ELECTRONICO INTEGRADO',
      'CIRCUITO ELECTRONICO INTEGRADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85423999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-383443',
      'INTERRUPTORES',
      '30mm Selector Switch 800T PB',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-404788',
      'PROVIENE DE BOM',
      'ETO:1000RR,MTG PLT,458 LADLE K350 FLANGE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-408974',
      'TERMINAL',
      'TERMINAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-411232',
      'ADHESIVO',
      'Loctite 3621 epoxy adhesive red 30 ml',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '35061001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-431979',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-453223',
      'SERVOMOTOR ELECTRICO DE CORRIENTE ALTERNA',
      'SERVOMOTOR ELECTRICO DE CORRIENTE ALTERNA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015205',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-465698',
      'TERMINAL',
      'TERMINAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-473860',
      'PANEL DE ALUMINIO',
      'PANEL DE ALUMINIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '76169999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-490319',
      'CERRADURA DE METAL CON LLAVE',
      'CERRADURA DE METAL CON LLAVE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '83014001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-498188',
      'CIRCUITO INTEGRADO',
      'CIRCUITO INTEGRADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85423999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-501406',
      'TRANSFORMADOR DE DISTRIBUCION',
      'TRANSFORMADOR DE DISTRIBUCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '34031999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-505565',
      'CERRADURA',
      'CERRADURA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '83014001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-532076',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-54037',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-543774',
      'CIRCUITO IMPRESO',
      'CIRCUITO IMPRESO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-575099',
      'BUS FLEXIBLE',
      'BUS FLEXIBLE',
      'MAT',
      'Materias Primas',
      'MT',
      'KG',
      '85369007',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-575100',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-74969',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-75427',
      'CIRCUITO MODULAR',
      'CIRCUITO MODULAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389005',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-83057',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-98443',
      'CONTROLADOR',
      'CONTROLADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90328999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C134376',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'MOTOR,SERVO,FDUPGRADE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C134715-65700691',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C163822-65681955',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C166831',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27351',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34036',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
