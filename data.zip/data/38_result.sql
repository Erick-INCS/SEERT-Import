INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005734339-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '104-C85DJ22 B',
      'CONTACTOR',
      'CONTACTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10576594',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10587959',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10621913',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10656727',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10700335',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10702273',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10707463',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10718227',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10794739',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10810618',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10817880',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10835148',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10844610',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10847870',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE015D A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE018WB A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE110D A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB050UA A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-N38 A',
      'TERMINAL',
      'TERMINAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '173196',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '190S-ANDJ1-CB16C B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '203080-A01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '23103-036-05',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '245067',
      'PARTES PARA VALVULA (BOLA Y SELLO)',
      'PARTES PARA VALVULA (BOLA Y SELLO)',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '26115',
      'CONDENSADORES',
      'CONDENSADORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322499',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30126-565-02',
      'PROVIENE DE BOM',
      'ETO: BRK UPPER XFMR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30150-480-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30155-381-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30164-202-01',
      'PROVIENE DE BOM',
      'BUS, HORIZ',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30164-218-01',
      'PROVIENE DE BOM',
      'ETO: BUS, L1, LCL OUTPUT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '321761-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '353678',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '372173-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '387051-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-082-39',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-219-21',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-279-35',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40113-163-22',
      'PROVIENE DE BOM',
      'VERT SLD UNIT CONN',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-750-07',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40121-799-22',
      'CAPACITORES',
      'CAPACITORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85321099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40124-009-26',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40382-180-51',
      'PROVIENE DE BOM',
      'COVER SUB-ASSY.',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40432-473-09-0273',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40751-325-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-368-57',
      'PROVIENE DE BOM',
      'E3 SENSING MODULE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201850047B116B116',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '512-DCB-26R 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DSB-E6880 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1172',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1231',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2005',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-532',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-617',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-637',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-672',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-804',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-960',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503727582-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503780534-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-181',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-501',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504127127-500',
      'TEMP',
      'TEMP',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504339101-945',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B4011924002',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6ELS-16',
      'SENSOR',
      'SENSOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90328999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7/32 1/2',
      'ORGANOS DE ACOPLAMIENTO',
      'ORGANOS DE ACOPLAMIENTO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84836099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74101-169-75',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74102-392-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74106-820-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74198058',
      'TECLADO PARA PANEL DE CONTROL',
      'TECLADO PARA PANEL DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE188 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WF157 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FM-LF5PN7YX10 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800H-AR2A4 F',
      'BOTON PARA INTERRUPTOR',
      'BOTON PARA INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-2GT T',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '802276-605R',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '8172abebafddadb86aefb024235fe7',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '913FK6000',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94436901',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DETAIL,NC=DS021925',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DS6708-SR20007ZZR',
      'EQUIPO DE PRUEBAS CON ACCESORIOS',
      'EQUIPO DE PRUEBAS CON ACCESORIOS',
      'ACT',
      'Equipo',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6_3201796201',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-CBK-71',
      'PROVIENE DE BOM',
      'MCC2100 Circuit Breaker',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-12',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-26',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-UNIT-CENG',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WRP-4',
      'PROVIENE DE BOM',
      'MCC2100 Wrap',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MMC1-SP0000458',
      'JUEGO DE EMPAQUETADURAS CON ACCESORIOS',
      'JUEGO DE EMPAQUETADURAS CON ACCESORIOS',
      'MAT',
      'Materias Primas',
      'SET',
      'KG',
      '84849099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MPDL-13/7-TCK',
      'JUEGO DE CONVERSION',
      'JUEGO DE CONVERSION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P-TOUCH LABEL',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PLASTIC CONTAINER',
      'CAJA DE PLASTICO',
      'CAJA DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-106026',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-108370',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-117647',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-120442',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-136886',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-139050',
      'PROVIENE DE BOM',
      'Bul. 294, Drive Base Assy - SB IPS D1P5',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-142241',
      'PROVIENE DE BOM',
      'ASSY,PF700 FR2,PWR,10HP,240V,CONF.COATED',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-15857',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-16086',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-168193',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-176006',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-18269',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-186103',
      'PROVIENE DE BOM',
      'PCBA 440L LGS 14mm Rec A Module',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-187451',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-195184',
      'RIEL DE MONTAJE (HERRAJE)',
      'RIEL DE MONTAJE (HERRAJE)',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83024999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-198722-65755932',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-215749',
      'PANEL DE CONEXIONES SIN SUS APARATOS',
      'ETO: INDUSTRIALNET 8PORT DIN PATCH PANEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-223413',
      'PROVIENE DE BOM',
      'RISER,FOR CB MTG PLATE,VULCAN,AMAT',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-223598',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-227202',
      'MODULO PARA CONTROLADOR DE VELOCIDAD',
      'MODULO PARA CONTROLADOR DE VELOCIDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-230605',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-26600',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-286889-65343806',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-289634',
      'PROVIENE DE BOM',
      'ERICO 3x20x1-34"',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-289767',
      'PROVIENE DE BOM',
      'FM Assembly, Programmed, IC CY8C4245PVI',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-289843',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-291097',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-293513',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-298989',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-328742',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-341987',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-344239',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-353348',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-354749',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-380802',
      'APARATO PARA COMUNICACION EN RED',
      'Stratix 2000 8T Port Unmanaged Switch',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85176299',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-395728',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-458485',
      'VENTILADOR',
      'VENTILADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84145999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-483056',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-497142',
      'BASE PARA LAMPARA',
      'BASE PARA LAMPARA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '94059999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-497271',
      'TRANSFORMADOR ELECTRICO',
      'TRANSFORMADOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85043199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-504060',
      'PANEL DE ENSAMBLE',
      'PANEL DE ENSAMBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-508816',
      'INDUCTORES',
      'INDUCTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85045099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-510920',
      'APARATO DE ACONDICIONAMIENTO DE AIRE',
      'APARATO DE ACONDICIONAMIENTO DE AIRE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84158299',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-511116',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-529107',
      'RELEVADOR',
      'RELEVADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-531520',
      'RELEVADOR',
      'RELEVADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-550612',
      'IMPRESOS',
      'IMPRESOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '49011001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-581357',
      'GABINETE ESPECIAL',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-58143',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-90609',
      'CABLE ELECTRICO CON CONECTORES',
      'CABLE ELECTRICO CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-92669',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C77249',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'POWERFLEX 700S',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C79812-65699351',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94377-65756714',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94989',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C96102',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C98110',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D10608',
      'PROVIENE DE BOM',
      'STRTR,SZ2,W/O OLR,HVY,120V,60HZ',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167350',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167583',
      'PROVIENE DE BOM',
      'L1-3 STAB&amp;WIRE,110A,140G-J,VERT,SNGL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167731',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170704',
      'PROVIENE DE BOM',
      'VPC-165xx-SY M940 Internal Parts (P)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D176837',
      'FLECHA',
      'FLECHA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84831001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D177223',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E000155',
      'PROVIENE DE BOM',
      'ETO: HORZ INTERPHASE BARRIER, 2500A BRKR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E006335',
      'BUSES',
      'BUSES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369007',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E013582',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E016100',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E026082',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E026909',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E060827',
      'GABINETE',
      'GABINETE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'ROCKWELL-SCREW',
      'TORNILLOS DE ACERO',
      'TORNILLOS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181506',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SCA-300003102',
      'MANUFACTURA DE METAL',
      'MANUFACTURA DE METAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'T4631-306',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TOP & BOT SPRT PLATE',
      'PLACA AISLANTE',
      'PLACA AISLANTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85472099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'VCOM USB 2.0 CABLE',
      'CABLE CON CONECTORES',
      'CABLE CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'VPH 100',
      'BLOQUE PLASTICO',
      'BLOQUE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'XV95',
      'SEPARADOR PLASTICO',
      'SEPARADOR PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Y-355432',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'd9ead82102a5be3727e66413a8ef10',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '0002-1734-65336195',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '07/01/2168',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '0cc10c8ed4d5c163be7c9249be5fe9',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1 PHILIPS',
      'CUBO DE AJUSTE INTERCAMBIABLE',
      'CUBO DE AJUSTE INTERCAMBIABLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '82042099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000392938 DRW 000 01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000678287 SHT 3',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000679968 SH2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001653592-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001656348-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001687196-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001704558-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001705825-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001729274-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001729276-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002525313-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002684917 SH 2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10003690742-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005482844-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005575130-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005575142-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005657028-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005681633-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005697591-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005732187-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10544897',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10598716',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10607371',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10615629',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10644253',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10669016',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10707093',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10712205',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10718489',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10745690',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10807437',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10810940',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10846370',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '11/11/2523',
      'ARANDELA DE SEGURIDAD',
      'ARANDELA DE SEGURIDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '12 COPPER WIRE',
      'CABLE ELECTRICO',
      'CABLE ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444904',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE025TA A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE120UC A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE170X A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACS005B A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CABLE200WD C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '15-00263R',
      'CAPACITOR',
      'Cap,2200pF,50VDC,5%,Cer,COG,0603,SMD',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '74040099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1913662',
      'CONECTOR',
      'CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '195954-Q01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24707-014-05',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24707-024-61',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '25111-033-12',
      'PANEL DE CONEXION',
      'PANEL DE CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30139-360-02',
      'PROVIENE DE BOM',
      'ETO: MTG BRACKET',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30139-627-01',
      'PROVIENE DE BOM',
      'BRACKET, CORE BUS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30161-324-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30165-410-03',
      'PROVIENE DE BOM',
      'ETO: BUS BAR, LOAD L3',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30165-507-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30172-039-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31275-190-06',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '347546',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-219-26',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40116-438-21',
      'PROVIENE DE BOM',
      'SM HANDL MECH ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40121-891-05',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40126-843-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40266596010273BCAB',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40405-462-03-2273',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40854-014-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40888-524-05-C1FX',
      'PROVIENE DE BOM',
      'PRINCIPLE ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41164-217-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '45006-339-09',
      'ETIQUETAS DE PLASTICO',
      'ETIQUETAS DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39199099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '50.054.100',
      'INTERRUPTOR DE TEMPERATURA',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '50054109',
      'CONTENEDOR PARA DESHECHOS',
      'CONTENEDOR PARA DESHECHOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39233001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '500L-FAA93 L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '50236003',
      'CIRCUITOS IMPRESOS',
      'CIRCUITOS IMPRESOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84834099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FAH-A2N L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FJB-B1N-6P L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DAAD-A2K-44 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DDB-I7510 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DUC-3-47 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-EEC-48 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '55',
      'TABLERO  DE PRUEBAS  2 SECCIONES FORMADO  POR:  . ANALIZADOR DIELETRICO   MCA   ASSOCIATED   MODELO    5704,   PROBADOR   ALTO VOLTAJE  MARCA  HIOKI  ',
      'TABLERO  DE PRUEBAS  2 SECCIONES FORMADO  POR:  . ANALIZADOR DIELETRICO   MCA   ASSOCIATED   MODELO    5704,   PROBADOR   ALTO VOLTAJE  MARCA  HIOKI  ',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '90308999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '60002085',
      'RELEVADOR',
      'RELEVADOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85364199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6189V-DVICBL2 A',
      'CABLE ELECTRICO CON CONECCIONES',
      'CABLE ELECTRICO CON CONECCIONES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502397323-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1392',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1571',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1630',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1944',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2110',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-605',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503737702-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-114',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-148',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6bc91eaaabd788b549e71b044dec56',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-C01125',
      'RESORTE',
      'RESORTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73202001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '73d1b3090ae6a779b184d3e3895b27',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74104-467-472',
      'PARTES PARA MAQUINA DE PRUEBA ELECTRICA',
      'PARTES PARA MAQUINA DE PRUEBA ELECTRICA',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74106-400-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '77163-610-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE119 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE299 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WF138 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WS188 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WT198 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE183 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE222 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WT191 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80178-382-56',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80199-666-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80253-379-62',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80300-006-63',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '9101-2358',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '93416401',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94564691',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '96362003',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '97384010',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '99-01110',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'APA40059901 PACKAGING',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'B-17308',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000612854',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6_32018-046-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'E6001158334-1',
      'PHYSICAL INVENTORY CARDS',
      'PHYSICAL INVENTORY CARDS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '49119999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'FILTRO MARCA IMPELL',
      'FILTRO MARCA IMPELL',
      'FILTRO MARCA IMPELL',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'LAMINA',
      'LAMINA',
      'LAMINA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EBLK-7',
      'PROVIENE DE BOM',
      'MCC2100 Empty Block',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-ECABLE-14',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EHA-23',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-FUNIT-18',
      'PROVIENE DE BOM',
      'MCC2100 Frame Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PUNIT-93',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PUNIT-94',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WHA-31',
      'PROVIENE DE BOM',
      'MCC2100 Wire Harness',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WRP-70',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCF0201FT374',
      'RESISTENCIA FIJA',
      'RESISTENCIA FIJA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MFFER8/68/230',
      'PUNTO DE ACCESO PARA COMUNICACION',
      'PUNTO DE ACCESO PARA COMUNICACION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85437099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'O-56923-15',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'O-57408-1C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P318026',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P342498',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P363980',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PA400-569-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-102980',
      'PROVIENE DE BOM',
      'SMC 50,140-180A 480V PWR POLE &amp; HES ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-104442',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-106956',
      'PROVIENE DE BOM',
      'PKG MDL ASSY,RED PS ADPTR,ROHS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-117634',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-126278',
      'MODULO CONTROLADOR',
      'MODULO CONTROLADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-126724',
      'BOTON INTERRUPTOR',
      'BOTON INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-127326',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-129282',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-132737',
      'PROVIENE DE BOM',
      'BUFFER-PWR LYR,600V,20HP,RHINO,FR 3',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-135918',
      'PROVIENE DE BOM',
      'PCBA, E3, 45mm,  EC3&amp;5, 1-5A sens, RoHs',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-170972',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-174854',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-177077',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-196253-65350744',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-198014',
      'PROVIENE DE BOM',
      'Kone Harness 1000K-34487003 A',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-201053',
      'PROVIENE DE BOM',
      'CEP9 E300 sen mod IEC dir mt IG 30A C55',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-203927',
      'CONECTOR',
      'CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205719',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'Kinetix VP Low Inertia Servo Motor',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015205',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-209238-65353047',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-212935',
      'PROVIENE DE BOM',
      'P/C T, 317254-Q01',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-222068',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-224225',
      'PROVIENE DE BOM',
      'BRACKET,CABLE TIE BRKT,VULCAN,AMAT',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-228083',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-279240',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-285225',
      'INDUCTORES',
      'INDUCTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85045099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-315136',
      'CONECTOR ELECTRICO',
      'CONECTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-349068',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-349127',
      'CIRCUITO INTEGRADO',
      'CIRCUITO INTEGRADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85423199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-389817',
      'CONTROLADOR DE VELOCIDADN PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDADN PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-428232',
      'CABLE ELECTRICO SIN CONEXION',
      'ETO: WIRE,MTW 16 GRN/YEL STR 500 REEL',
      'MAT',
      'Materias Primas',
      'MT',
      'KG',
      '85444904',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-457849',
      'INSERTO PARA CONTACTO',
      'INSERTO PARA CONTACTO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-458366',
      'CERRADURA DE LLAVE',
      'KirkKey Lock,KFL000010ST,3Lock,2Key',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '83014001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-458905',
      'PLACA (CUBIERTA)',
      'ETO: FACEPLATE, 2 PORT',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-477582',
      'BOLSA PLANA PLASTICA',
      'BOLSA PLANA PLASTICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39232101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-50274',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-503935',
      'PIEZA AISLANTE',
      'PIEZA AISLANTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85321001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-51428',
      'PROVIENE DE BOM',
      'PID ULTRA PASSIVE SHUNT,,4.29X1.35,',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-519725',
      'CABLE ELECTRICO CON CONECTOR',
      'CABLE ELECTRICO CON CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-541120',
      'INTERRUPTOR DE SEGURIDAD',
      'INTERRUPTOR DE SEGURIDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-543785',
      'CUBIERTA PARA GABINETE',
      'CUBIERTA PARA GABINETE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-57547-65307230',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-75334',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C13511',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C76713-65703178',
      'CONTROLADOR DE VELOCIDAD',
      'CONTROLADOR DE VELOCIDAD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94220',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C96648',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C98156',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167390',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D168706',
      'DISYUNTOR',
      'DISYUNTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170405',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170649',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170835',
      'PROVIENE DE BOM',
      'VPC-300 5-STD 3-BRK,S/A,FAN KIT (P)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D177227',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E000132',
      'PROVIENE DE BOM',
      'ETO: L1-L3 LUG PAD, FRONT, 2500A BREAKER',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E015023',
      'PROVIENE DE BOM',
      'ETO: L1 HORIZ CONN TO BUS DUCT 0.25 2191',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E019171',
      'PROVIENE DE BOM',
      'MTG BRACKET TO MOUNT DIN RAIL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E036327',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SCH-403985',
      'TARJETA DE CIRCUITO MODULAR',
      'TARJETA DE CIRCUITO MODULAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389005',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SD CARDS',
      'TARJETA DE ALMACENAMIENTO (SD)',
      'TARJETA DE ALMACENAMIENTO (SD)',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85235101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SMS-M BLOCK BEARING',
      'RODAMIENTO LINEAL DE BOLAS',
      'RODAMIENTO LINEAL DE BOLAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84821099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'STM-414700',
      'CUBIERTA',
      'CUBIERTA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TALADRO DE PEDESTAL',
      'TALADRO DE PEDESTAL ',
      'TALADRO DE PEDESTAL ',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'W7420',
      'DIODO EMISOR DE LUZ',
      'DIODO EMISOR DE LUZ',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '050c9e982f1cfafb5e95125c50f16b',
      'SISTEMA AUTOMATICO DE CORTE DE PANELES  ( ROUTER- 3)',
      'SISTEMA AUTOMATICO DE CORTE DE PANELES  ( ROUTER- 3)',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000664836 SH2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000678284 SHT 5',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000679968 SH6',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001587192-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001591633-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001609306-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001615206-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001653521-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001685895-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001712337-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001747860-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004609567-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005483078-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005539363-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005586236-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005654800-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656299-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656662-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005697620-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10391',
      'PARTES PARA HERRAMIENTA MANUAL',
      'PARTES PARA HERRAMIENTA MANUAL',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '82071999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-ATDJ3-CA40C A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-ATDJ4-S1802 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-AWDJ2-O9690 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '104S-C12D210CB',
      'CONTACTOR',
      'CONTACTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10561962',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10596185',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10601091',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10659268',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10682291',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10684466',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10800351',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10806842',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '136044',
      'SUJETADOR METALICO',
      'SUJETADOR METALICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACAB016AA69 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACS025C A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB060WB A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1494V-DR616-A-D-E3',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1686082',
      'TAPAS PARA MOTOR ELECTRICO',
      'TAPAS PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1791DS-IB8XOB8A',
      'MODULO CONTROLADOR',
      'MODULO CONTROLADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '194RC-NJ060P6 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '20-750-EMC1-F3',
      'PLACA DE MONTAJE PARA CONTROLADOR',
      'PLACA DE MONTAJE PARA CONTROLADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85049099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '21540-451-05',
      'CAPACITORES DE PELICULAS PLASTICAS',
      'CAPACITORES DE PELICULAS PLASTICAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322502',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '2b26de800e43c3ef2c689193fce7db',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-052-06',
      'PROVIENE DE BOM',
      'ETO: VERT WWY MOD W/2ND NAMEPLATE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-249-74',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-287-73',
      'PROVIENE DE BOM',
      'MTG STRAP MOD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-320-42',
      'PROVIENE DE BOM',
      'ETO: MTG PLATE MOD FOR FUSE BLK MTG PLTE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-357-57',
      'PROVIENE DE BOM',
      'ETO: MOUNTING PLATE MOD, 1 SF',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30108-190-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30111-273-02',
      'PROVIENE DE BOM',
      'BRACKET, MOUNTING',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30125-697-01',
      'PROVIENE DE BOM',
      'RAIL CRADLE FRAM-B',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30126-007-01',
      'PROVIENE DE BOM',
      'ETO: SUPPORT CHANNEL, UPPER, XFMR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30139-775-02',
      'PROVIENE DE BOM',
      'MTG PLATE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30165-577-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30176-970-01',
      'PROVIENE DE BOM',
      'INTERPHASE BARRIER',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30342-310-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '3040010303S003',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '311-1.00KCRCT-ND',
      'RESISTENCIAS FIJAS',
      'RESISTENCIAS FIJAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31275-130-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '346276-Q01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40119-206-11',
      'PROVIENE DE BOM',
      '3.0 SF DOOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40140-043-68',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40358-102-62',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40391-663-03',
      'PROVIENE DE BOM',
      'COLL OF LOOSE PARTS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40405-468-04-E278',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40420-359-52',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-371-77',
      'PROVIENE DE BOM',
      'PROGRAMMED ASSEMBLIES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201844434B116B168',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201847738B116B365',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '42205',
      'CONDENSADOR',
      'CAPACITR-TANT-4.7uF-20V-10Por-SMT-3528-21',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '50054028',
      'CONTENEDOR PARA DESHECHOS',
      'CONTENEDOR PARA DESHECHOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39233001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '502-DFB-26R 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-DCB-B1K E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DCB-38104 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DCB-M1568 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DCBD-3-4G-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DJB-Q2492 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DSB-6GP-47 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1258',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1434',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1635',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2022',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2088',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-261',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-310',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-387',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-465',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-319',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-392',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-393',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6_22698468',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-L602969',
      'SUJETADOR',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83024999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75020-428 DRW 000 05',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75048-458-15',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7765139',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7776864',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7779797',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80011-0198-001',
      'CONDENSADORES',
      'CONDENSADORES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85322499',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WF246 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE246 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-1TW-40443 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80178-621-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '8222-41228601-LSI-7726',
      'INSERTADORA  DE  COMPONENTES ',
      'INSERTADORA  DE  COMPONENTES ',
      'ACT',
      'Maquinaria',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '91290A202',
      'TORNILLOS DE ACERO',
      'TORNILLOS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181506',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '96892802',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'AI, 10002770303',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'ASSEMBLY FIXTURE',
      'PIEZA DE ENSAMBLE PLASTICO',
      'PIEZA DE ENSAMBLE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BS07A',
      'INSERTO ROSCADO',
      'INSERTO ROSCADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BSTA082',
      'CONECTOR ELECTRICO',
      'CONECTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CARPENTER M36A AUTO',
      'CORTADORA DE CONTROL NUMERICO',
      'CORTADORA DE CONTROL NUMERICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84623103',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CE24-02-08588',
      'TARJETA DE CONTROL',
      'TARJETA DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'D7-17WE165 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'FX301B-03',
      'APARATO DE SOLDADURA DIGITAL',
      'APARATO DE SOLDADURA DIGITAL',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '85151199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'G44DK',
      'ACOPLADOR DE ALUMINIO',
      'ACOPLADOR DE ALUMINIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'GREENLEE CRIMPER',
      'HERRAMIENTA ELECTRICA DE CRIMPADO DE USO MANUAL',
      'HERRAMIENTA ELECTRICA DE CRIMPADO DE USO MANUAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84672999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'INSTRUCTION MANUAL 2100-5.28',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'JSZX01-0001-B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MARK PER : 10000147840',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-CBK-2',
      'PROVIENE DE BOM',
      'MCC2100 Circuit Breaker',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-27',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-49',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-ECABLE-5',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MKXR3W31504J00K5L9',
      'CAPACITOR',
      'CAPACITOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322599',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MOD DIR 10002074452',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P102150',
      'APARATO DE REDES DE AREA LOCAL',
      'APARATO DE REDES DE AREA LOCAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85176201',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
