INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10603752',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10615689',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10618284',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10653749',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10656735',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10656769',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10659282',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10682225',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10723497',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10820682',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10835621',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE075Y A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CABLE150N3 C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB400X A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1494V-DHX611-A-D 3',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '151',
      'TABLERO  DE PRUEBAS COMPUESTO POR : MEDIDOR MCA. ALIGENT MODELO 34972A,COMPUTADORA INDUSTRIAL MCA. ALLEN-BRADLEY MODELO 1450R, NOBRAKE MARCA TRIP-LITE',
      'TABLERO  DE PRUEBAS COMPUESTO POR : MEDIDOR MCA. ALIGENT MODELO 34972A,COMPUTADORA INDUSTRIAL MCA. ALLEN-BRADLEY MODELO 1450R, NOBRAKE MARCA TRIP-LITE',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '90308999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '189615-Q02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '191414-Q43',
      'RESISTENCIAS FIJAS',
      'RESISTENCIAS FIJAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '192653',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '28523',
      'RESISTENCIA',
      'RESISTENCIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85334099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30100-278-62',
      'PARTE MOLDEADA PARA CONECTOR',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30100-377-19',
      'PROVIENE DE BOM',
      'ETO: REPLACE FUSE LABEL, 90A JKS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-714-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30107-836-06',
      'PROVIENE DE BOM',
      'ETO: DIN RAIL MOD',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30115-252-21',
      'CUBIERTA PARA ARMARIO',
      'CUBIERTA PARA ARMARIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30122-194-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30161-441-01',
      'PROVIENE DE BOM',
      'ETO:L1 RISER (EXT TOP)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30169-519-01',
      'PROVIENE DE BOM',
      'LUG L2 FOR 400A DS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30187-560-01',
      'PROVIENE DE BOM',
      'ETO: POLYCARBONATE BARRIER',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '337186',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '359946',
      'PROVIENE DE BOM',
      'P6,P7,NEMA 4/12 DS OPTION 600A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '3671-DF-15',
      'DISPENSADOR METALICO PARA FLEJE, MOVIBLE',
      'DISPENSADOR METALICO PARA FLEJE, MOVIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '380387-Q01',
      'BOLSAS DE POLIETILENO',
      'BOLSAS DE POLIETILENO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39232101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '389485-Q01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85045099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40119-909-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40126-931-08',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40137-568-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40140-057 SH2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'SET',
      'SET',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40263-322-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40425-475-04-3236',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-466-52',
      'PROVIENE DE BOM',
      'ARMST SERIES C FRONT ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-367-56',
      'PROVIENE DE BOM',
      'SENSING MODULE ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40869-102-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-491-10-S1FX',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201841140B425B425',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201843949A044B116',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '440L-P2KA1760YD',
      'DISPOSITIVO FOTOSENSIBLE PARA DETECCION DE OBJETOS',
      'DISPOSITIVO FOTOSENSIBLE PARA DETECCION DE OBJETOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '440L-T4J0640YD',
      'DISPOSITIVO FOTOSENSIBLE',
      'DISPOSITIVO FOTOSENSIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '46644600',
      'MODULO DE CONTROL',
      'MODULO DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FAN L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '512-DAB-A1K-25R 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-CJA-I7032 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DABD-Q7169 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DFBD-Q2990 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '543447a140681d91dc4c905ac2d391',
      'CARRUSEL   VERTICAL,CAPACIDAD   9040   LBS,FECHA:   10-06-95',
      'CARRUSEL   VERTICAL,CAPACIDAD   9040   LBS,FECHA:   10-06-95',
      'ACT',
      'Maquinaria',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '59fe908f29bdb93951a71164d331aa',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '60.012.280',
      'SENSOR FOTOELECTRICO',
      'SENSOR FOTOELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6498K981',
      'CILINDRO NEUMATICO',
      'CILINDRO NEUMATICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84123199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502612596-300',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1183',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1241',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1250',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1473',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1502',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1509',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1702',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1718',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1909',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1937',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-219',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-254',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-537',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503968006-100',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-278',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-387',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '73157223',
      'EMPAQUE DE CAUCHO',
      'EMPAQUE DE CAUCHO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '40169399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74102-368-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75049-531',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE222 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WF283 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FP-LG3PD2CX11 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-QCL424RRRR P',
      'LUZ PILOTO',
      'LUZ PILOTO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85318099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80120-203-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80149-506-56',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80160-060-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '802274-206R',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80300-264-54',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '92469401',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Assembly Drawing_1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CY7C1021BNL-15ZSXAT',
      'CABLE ELECTRICO CON CONEXION',
      'CABLE ELECTRICO CON CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85423999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CZSPC-0386',
      'VARILLA DE PLASTICO PARA LIMPIEZA',
      'VARILLA DE PLASTICO PARA LIMPIEZA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000656500',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000664891',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DOC:  41053-370 Version 3',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6B40110-04',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Feb-25',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'INSTALLATION MATERIA',
      'REPUESTO PARA INTERRUPTOR',
      'REPUESTO PARA INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'K70003111',
      'CUBIERTAS DE SUJECION CON ACCESORIOS PARA MAQUINA ENSAMBLADORA DE COMPONENTES',
      'CUBIERTAS DE SUJECION CON ACCESORIOS PARA MAQUINA ENSAMBLADORA DE COMPONENTES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-FBLK-6',
      'PROVIENE DE BOM',
      'MCC2100 Finished Block',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PDOOR-6',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PUNIT-31',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PBSBOA0531',
      'UTIL PARA PUNZONAR',
      'UTIL PARA PUNZONAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82073001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PF4000-G-HW',
      'MODULO DE CONTROL',
      'MODULO DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-102500-65352581',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-103486',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110241',
      'PROVIENE DE BOM',
      'VPL-A1152F,S/A,HSG-STR-EC,KE45,(PHANTOM)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110309',
      'PROVIENE DE BOM',
      'VPL-1306,ROTOR-SHAFT,STEG,KEY,(PHANTOM)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110320',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-113414',
      'PROVIENE DE BOM',
      'BUFFER-POWER LYR PCB,FR 1,2HP,400/480V',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-115256',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-134399',
      'CONECTOR',
      'ETO: UNIVERSAL MODULE CAT 6',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-146336',
      'CABLE CON CONECCION',
      'CABLE CON CONECCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-14697',
      'PROVIENE DE BOM',
      'IP67 DB1 VFD BRK EMI',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-15864',
      'ARRANCADOR COMBINADO DE DESCONEXION DE FUSIBLES',
      'ARRANCADOR COMBINADO DE DESCONEXION DE FUSIBLES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-162122',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-168196',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-174394',
      'PROVIENE DE BOM',
      'BUL150-SC* 320A  690V PWRSEC FBKT ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-190289',
      'CUBIERTA PARA BLOQUE DE TERMINALES',
      'CUBIERTA PARA BLOQUE DE TERMINALES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-197216',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-199299',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-200887',
      'PROVIENE DE BOM',
      'BUL150-SB 24VDC 110A 480V PWR FAN TC ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205402-65752030',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-214584',
      'PROVIENE DE BOM',
      'PCBA, 440L 14mm Receiver A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-215831',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-235142',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-240960',
      'PANEL DE DISTRIBUCION',
      'PANEL DE DISTRIBUCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-267479',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICO',
      'Variable Frequency Drive',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-268952',
      'PROVIENE DE BOM',
      'P/C T, 179369',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-272064',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-272739',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-300434',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-312930',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-349622',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-350123',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-365251',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-366087',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-37765-65349379',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-388397',
      'CABLE ELECTRICO SIN CONECCIONES',
      'CABLE ELECTRICO SIN CONECCIONES',
      'MAT',
      'Materias Primas',
      'MT',
      'KG',
      '85444904',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-406095',
      'RELEVADOR',
      'ETO: Relay',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-467145',
      'RESISTENCIA',
      'RESISTENCIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '74040099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-471219',
      'ETO: SEL-849 MOT',
      'ETO: SEL-849 MOT',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-474887',
      'PANEL DE CONTROL DESENSAMBLADO',
      'PANEL DE CONTROL DESENSAMBLADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-494716',
      'SERVOMOTOR ELECTRICO DE CORRIENTE ALTERNA',
      'SERVOMOTOR ELECTRICO DE CORRIENTE ALTERNA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-495994',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-501447',
      'ETIQUETAS DE PAPEL IMPRESAS',
      'ETIQUETAS DE PAPEL IMPRESAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '48211001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-508880',
      'TRANSFORMADOR ELECTRICO',
      'TRANSFORMADOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-51566',
      'PROVIENE DE BOM',
      'S/A,HSG-STR-EC,MPM-165,A1653F,BRK',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-528874',
      'RESISTOR',
      'RESISTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-542796',
      'SERVO MOTOR',
      'SERVO MOTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85013205',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-548410',
      'CIRCUITO MODULAR',
      'CIRCUITO MODULAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85389005',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-549616',
      'FOLLETOS',
      'FOLLETOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '49011099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-561711',
      'PIE DE MONTAJE CON TORNILLOS',
      'PIE DE MONTAJE CON TORNILLOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-569682',
      'REACTOR DE LINEA',
      'REACTOR DE LINEA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85045099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-576134',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-583628',
      'TERMINAL',
      'TERMINAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-61106',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67487-65307257',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-70744',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-71526-65347820',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-89679',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-91764',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-94200',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-94936-65878930',
      'CONTROLADOR DE VELICIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELICIDAD PARA MOTORES ELECTRICOS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C10153',
      'CHASIS PARA MODULO DE CONTROL',
      'CHASIS PARA MODULO DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C166970',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27479',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34079',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94113',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C96053',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D165287',
      'MODULO DE CONTROL',
      'MODULO DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167451',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167490',
      'PROVIENE DE BOM',
      '2100 STAB ASSY,180A,140G-J,HIGH,VRT,SNGL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170726',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170772',
      'PROVIENE DE BOM',
      'VPC 165 S/A ENCODER DSL M740 (P)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E028931',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E029769',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E031787',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E036395',
      'SOPORTE METALICO',
      'SOPORTE METALICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E073936',
      'GABINETE',
      'GABINETE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PP-285-1592-0',
      'JUEGO DE REPARACION PARA VALVULA',
      'JUEGO DE REPARACION PARA VALVULA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84819099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'S2221EC-30-ND',
      'CONECTORES ELECTRICOS',
      'CONECTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TVX-02PCB',
      'CIRCUITO MODULAR',
      'CIRCUITO MODULAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '90309002',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'UV-LIGTH FIXTURE',
      'LAMPARA DE TECHO O PARED',
      'LAMPARA DE TECHO O PARED',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '94051003',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'VHS20-N02A-Z',
      'VALVULA',
      'VALVULA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84812099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'WHEELED TABLE',
      'MESA DE METAL CON RUEDAS',
      'MESA DE METAL CON RUEDAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '94032099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Y-355430',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'YAG1673DKR-ND',
      'RESISTENCIAS',
      'RESISTENCIAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'a3a7dbf34ecdc906752f1420cd6478',
      'MAQUINA PARA BALANCEO DE ROTOR 
',
      'MAQUINA PARA BALANCEO DE ROTOR ',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '05/29/2434',
      'PROVIENE DE BOM',
      'CTN-HOT SURFACE,PLYSTR,0.46X2.07,',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001011239-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001242855-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001552780-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001603843-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001688845-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001689131-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002920764 SH2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004034271-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004047807-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004394368-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005555628-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005632370-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656514-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656640-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005682901-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005687165-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1000A-M/A97187 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-ATDJ2-CA16C A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10553181',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10588004',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10596203',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10601039',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10682425',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10702168',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10746226',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10800384',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10801723',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10820650',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10829345',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10838266',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE045H A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE200UD A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CABLE060TBCHC',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-N21 A',
      'CAJA DE PLASTICO',
      'CAJA DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1756-L73',
      'UNIDAD DE CONTROL',
      'UNIDAD DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85176202',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1756-M02AS A',
      'MODULO DE CONTROL',
      'MODULO DE CONTROL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1821161',
      'CUBIERTA PARA MOTOR',
      'CUBIERTA PARA MOTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '189764',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '190S-ANDJ2-CB25S B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '191414-Q61',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '203175-A01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '3-2003',
      'CIRCUITO IMPRESO',
      'CIRCUITO IMPRESO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30 MM',
      'CUBO (DADO) DE AJUSTE INTERCAMBIABLE',
      'CUBO (DADO) DE AJUSTE INTERCAMBIABLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '82042099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30106-650-15',
      'PROVIENE DE BOM',
      'DIN RAIL MOD',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30116-291-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30130-234-08',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30138-819-02',
      'PROVIENE DE BOM',
      'MTG BRACKET',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30165-279-02',
      'PROVIENE DE BOM',
      '1/4 X 1.00 GRD BUS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30186-580-01',
      'PIEZA ASILANTE DE PLASTICO',
      'PIEZA ASILANTE DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85472099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30251-30500',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83099004',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30342-229-02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '3070',
      'CIRCUITO MODULAR PARA EQUIPO DE PRUEBAS DE TARJETAS ELECTRONICAS',
      'CIRCUITO MODULAR PARA EQUIPO DE PRUEBAS DE TARJETAS ELECTRONICAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '90309002',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '309442-C02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '311-1 00KFRCT-ND',
      'RESISTOR',
      'RESISTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31275-135-07',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '337870-A02',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '362540-F01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '384502',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-082-07',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-217-04',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-219-32',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-031-18',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40119-879-08',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40121-291-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40129-400-69',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40137-555-10',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40266596010249DECB',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40324-408-03',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40382-300-51',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-462 assy drawing',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-467-79',
      'PROVIENE DE BOM',
      'ASSEMBLY DRAWING',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-468 assy drawing',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-370-53',
      'PROVIENE DE BOM',
      'SENSING MODULE ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-371-84',
      'PROVIENE DE BOM',
      'PROGRAMMED ASSEMBLIES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40891-461-03-B2FX',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201854458B278B278',
      'PROVIENE DE BOM',
      'CUT WIRE LUG BOTH ENDS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '42336-173-53',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '500LP-FAA92 L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '507-DJB-1-6P-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FED C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DJB-D9499 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DJBD-A2L-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '5214507',
      'RIELES PARA MONTAJE',
      'RIELES PARA MONTAJE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83024999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '57-993-10',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6)PLACE ITEMS 1,2 REFERENCE',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '602-1521-ND',
      'CONTROLADOR',
      'CONTROLADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85176202',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6079498-1',
      'MANUFACTURA DE ACERO',
      'MANUFACTURA DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82055999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1676',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1709',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1754',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1974',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2155',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2181',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-529',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-838',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-848',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-859',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-383',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504339101-872',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B:40140-755 FIG B',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-C01057',
      'ETIQUETAS IMPRESAS',
      'ETIQUETAS IMPRESAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84137099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75055-420',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7772245',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE168 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE272 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WF128 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE277 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WF124 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WF250 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-CAE-GE1 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FM-LF5MD3CX10 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FP-LF6PN7BX10 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-2TKM T',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80154-970-64',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80253-359-73',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80300-264-59',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '81010-178-54',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '819-1-1EA',
      'CUBIERTA PLASTICA DE SEGURIDAD',
      'CUBIERTA PLASTICA DE SEGURIDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '889R-F4APCS-5 B',
      'CABLE CON CONECTORES',
      'CABLE CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '91212',
      'TERMISTORES',
      'TERMISTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85334002',
      NULL,
      '2000.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '93406003',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94481501',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94567301',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '97-01464',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '97-01673',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '99-00944',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'A1014',
      'PLATO PARA VALVULA',
      'PLATO PARA VALVULA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84819099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'AF-1268',
      'PARTE ENSAMBLE PARA PROBADOR',
      'PARTE ENSAMBLE PARA PROBADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90319099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CANMET ',
      'CANASTILLAS DE METAL',
      'CANASTILLAS DE METAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73262099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CGA-350',
      'ACCESORIO DE TUBERIA DE COBRE( ADAPTADOR)',
      'ACCESORIO DE TUBERIA DE COBRE( ADAPTADOR)',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6B:40113204',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6_22543565',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'FLWBC5-9ZZA',
      'RODAMIENTO DE BOLAS',
      'RODAMIENTO DE BOLAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'G-104S WZ',
      'ACCESORIO DE TUBERIA GALVANIZADO',
      'ACCESORIO DE TUBERIA GALVANIZADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73079903',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'G-1SWZ',
      'HERRAJES DE METAL',
      'HERRAJES DE METAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73079903',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'JQVN95-0006',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Jul-93',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'LONG METAL RIVETS',
      'REMACHES DE ACERO',
      'REMACHES DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-CBK-15',
      'PROVIENE DE BOM',
      'MCC2100 Circuit Breaker',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-46',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-ECABLE-30',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-FBLK-15',
      'PROVIENE DE BOM',
      'MCC2100 Finished Block',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PCNT-100',
      'PROVIENE DE BOM',
      'MCC2100  Plug-in Unit Control Station',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PCNT-57',
      'PROVIENE DE BOM',
      'MCC2100  Plug-in Unit Control Station',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PDOOR-2',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MMC1-SP0001075',
      'MANGUERA DE PLASTICO CON ACCESORIOS',
      'MANGUERA DE PLASTICO CON ACCESORIOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39173399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'NPH-5018',
      'INSERTO ROSCADO',
      'INSERTO ROSCADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-104322',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-114521',
      'APARATO DE AIRE ACONDICIONADO',
      'APARATO DE AIRE ACONDICIONADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84158299',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-117541',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-123111',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-132847',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-138761',
      'PROVIENE DE BOM',
      'CUSHION, INSTAPAK, ASSEMBLY, IDM 130',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-141151',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-143481',
      'PROVIENE DE BOM',
      'REPLACED BY PN-E002299',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-153359',
      'ARMARIO SIN SUS APARATOS',
      'ARMARIO SIN SUS APARATOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-16091',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-168213',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-179733',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-195745',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-19726',
      'CABLE ELECTRICO CON CONECTOR',
      'CABLE ELECTRICO CON CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-200892',
      'PROVIENE DE BOM',
      'BUL150-SB 24VDC 180A 690V PWR FAN TC ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205648',
      'PROVIENE DE BOM',
      'ETO: 20WAY HART LINKING CABLE 2M',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-209238-65354583',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-211465',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-227871-65349997',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-235730',
      'PIEZA AISLANTE DE PLASTICO',
      'PIEZA AISLANTE DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85472099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-264576',
      'PROVIENE DE BOM',
      'P/C,MOV,S028, 24797-001-19',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-275644',
      'BOBINA DE REACTANCIA',
      'BOBINA DE REACTANCIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85045099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-276481',
      'PROVIENE DE BOM',
      'L1-2 STAB&amp;WIRE,3&amp;7A,140G-G,H,HORIZ,SNGL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-279198',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-279502',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-297071',
      'RESISTENCIAS',
      'RESISTENCIAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-307429',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-312924',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-313658',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-332948',
      'PROVIENE DE BOM',
      'P/C T, 220221-Q21',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-333797',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-338915',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-341984',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-38486',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-38490',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-38548',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-39754',
      'PROVIENE DE BOM',
      'ARMORSTART BASE ASSY  - SAFETY C25',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-402538',
      'CIRCUITOS IMPRESOS',
      'PCB Panelized,10-Up,9kLaserPolarizedDC',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-412477',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'PowerFlex 70 AC Drive 2.1 A at 1 Hp 20A',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-430165',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-48365',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-488657',
      'TRANSDUCTOR',
      'TRANSDUCTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85437099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-507976',
      'MOTOR DE CORRIENTE ALTERNA ASINCRONO TRIFASICO',
      'MOTOR DE CORRIENTE ALTERNA ASINCRONO TRIFASICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-508434',
      'ETIQUETAS DE PLASTICO AUTOADHESIVAS',
      'ETIQUETAS DE PLASTICO AUTOADHESIVAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39199099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-530040',
      'ARRANCADOR',
      'ARRANCADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-549944',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-570148',
      'ARMARIO',
      'ARMARIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-591656',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-600370',
      'INTERRUPTOR',
      'INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-97083',
      'BLOQUE DE CONEXION',
      'BLOQUE DE CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-97405',
      'FUSIBLES',
      'Cktpro Fuse TD 250V 2A 5X20mm',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85361099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C13428',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27404',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27439',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27600',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C34029',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C76673-65757669',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C95498',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D165987',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D166382',
      'PROVIENE DE BOM',
      'MCCB 140G-M 65kA/480V LSIG 800A3P',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167360',
      'PROVIENE DE BOM',
      'MCCB 140G-H 100kA/480V FF 60A 3p  w/Aux',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167720',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170317',
      'PROVIENE DE BOM',
      'VPC-1652D-Q,S/A,HSG-STATOR,Kexx(P)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170481',
      'PROVIENE DE BOM',
      'VPC-21549,S/A,STATOR,Kexx',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D176802',
      'LUZ INDICADORA',
      'LUZ INDICADORA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84833099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002718',
      'PROVIENE DE BOM',
      'ETO: L2 VERTICAL BARRIER, 2193MB ABB DRA',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E012401',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E016289',
      'PROVIENE DE BOM',
      'ETO: BUS,LUG,INOUT-OUTPUT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E029132',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E029205',
      'MANGUERA DE PLASTICO CON REFUERZO',
      'ETO: FAB,THERMOPLASTIC ELASTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39173999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E036520',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E038053',
      'BUSES',
      'BUSES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369007',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E075381',
      'CALCOMANIAS',
      'CALCOMANIAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '49089099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-F000261',
      'RESISTOR',
      'RESISTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'S3891',
      'PUERTA PARA GABINETE',
      'PUERTA PARA GABINETE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SME312FP',
      'DISPOSITIVOS SEMICONDUCTORES FOTOSENSIBLES',
      'DISPOSITIVOS SEMICONDUCTORES FOTOSENSIBLES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'WSP-323312',
      'ANILLO DE RETENCION',
      'ANILLO DE RETENCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182499',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '010E-6X9F',
      'PLACA PARA INTERRUPTOR',
      'PLACA PARA INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '100-D180-VLTBB',
      'PUENTE DE CONEXION',
      'PUENTE DE CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000169558 SHT 2',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000174901',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001587186-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001729227-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001791304',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002575890-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10004101271-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005483056-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005611561 Schema',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1003325514',
      'DISPOSITIVOS DE ALUMINIO PARA SUJECION',
      'DISPOSITIVOS DE ALUMINIO PARA SUJECION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-ATDJ2-R3924 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-ATDJ3-CB25R A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10551423',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10573853',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10577771',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10596187',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10606182',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10610920',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10700564',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10806739',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10830651',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1233X-DNCD-A1K-471',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1309f33ad9ecef8a48c548d46c2bc9',
      'TABLERO  DE  PRUEBAS  SIN  DATOS  EN  GABINETE  DE  MADERA  CON: CONECTORES Y ACCESORIOS',
      'TABLERO  DE  PRUEBAS  SIN  DATOS  EN  GABINETE  DE  MADERA  CON: CONECTORES Y ACCESORIOS',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '142492',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE150G A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CABLE110RTBOC',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CABLE120WN C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB050WB A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB250Y A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '160261',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '173105',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '190S-ANDJ2-I5409 B',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '191414-Q16',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '191448-Q09',
      'PROVIENE DE BOM',
      'CAP,MLC-1500pF,50V,5%,C0G,0805',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '191462-Q31-65334181',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '195941-Q06',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '21-301-413-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '2114920',
      'VARILLA DE ACERO
',
      'VARILLA DE ACERO
',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30116-263-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30120-089-15',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30127-607-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30132-401-02',
      'PLACA DE ENSAMABLE',
      'PLACA DE ENSAMABLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83024999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30138-427-02',
      'PROVIENE DE BOM',
      'BRACKET, MOUNTING, 1-GANG 800T DEVICE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30174-300-05',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '331009-A02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '340239-C01',
      'SOPORTE METALICO',
      'SOPORTE METALICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '367509-A01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '36c20805e79bd9919e5bb582242d77',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40110-030',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40140-057 SHT 3',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40194-465 DRW 000 01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40359-252-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40415-462-06-3236',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-366-51',
      'PROVIENE DE BOM',
      'MINI CONTACTOR ASSY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-468-51',
      'PROVIENE DE BOM',
      'STANDARD-NON REV B',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-468-85',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40888-495 DRW 000 02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40891-461-01-S1FX',
      'PROVIENE DE BOM',
      'MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '48010-035',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '50066301',
      'VENTILADORES',
      'VENTILADORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84145999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '512-DJB-A3K-26R 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DABD-A2L-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DCB-O2147 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DCBD-A2K-47 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DEC-52917 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DFB-M7382 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DFB-R1199 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DHB-C9228 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DHB-D2758 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '570-FAAD-50 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1066',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1332',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1574',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1696',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2128',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-266',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-964',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-112',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504339101-875',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6M06X016E0933',
      'TORNILLOS DE ACERO',
      'TORNILLOS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181504',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6_3201781801',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-2010',
      'CONDENSADOR.',
      'CONDENSADOR.',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '700-HK32Z24-3-4 B',
      'RELEVADOR',
      'RELEVADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '700-HV32AAU120 B',
      'RELEVADOR TEMPORIZADO',
      'RELEVADOR TEMPORIZADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74104-447-73-PR',
      'TARJETA ELECTRONICA PARA CONTROLADORES DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'TARJETA ELECTRONICA PARA CONTROLADORES DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
