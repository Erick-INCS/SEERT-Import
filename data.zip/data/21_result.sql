INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '440L-T4K1280YD',
      'DISPOSITIVO FOTOSENSIBLE',
      'DISPOSITIVO FOTOSENSIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '44170501',
      'ENSAMBLE SUJETADOR',
      'ENSAMBLE SUJETADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4605628',
      'RODAMIENTO DE RODILLOS CILINDRICOS, RODAMIENTOS DE RODILLOS CILINDRICOS',
      'RODAMIENTO DE RODILLOS CILINDRICOS, RODAMIENTOS DE RODILLOS CILINDRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84825001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '48850901',
      'BANDA DE CAUCHO',
      'BANDA DE CAUCHO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '40103999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '5',
      'MAQUINA  APLICADORA DE ADESHIVOS ',
      'MAQUINA  APLICADORA DE ADESHIVOS ',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '84798999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FAH-11269 L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '509-FJA-1 L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DEB-1-4G-47 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DFB-L9673 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '5209439',
      'VENTILADORES',
      'VENTILADORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84145999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '550-1529-02',
      'CAPACITORES ELECTROLITICOS DE ALUMINIO',
      'CAPACITORES ELECTROLITICOS DE ALUMINIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322299',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '60.012.227',
      'SENSOR FOTOELECTRICO',
      'SENSOR FOTOELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '624 691 3 01 RT',
      'JUEGO DE DADOS DE CRIMPADO',
      'JUEGO DE DADOS DE CRIMPADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82079099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '65-178',
      'CAVIDADES PLASTICAS',
      'CAVIDADES PLASTICAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39239099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502678340-300',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1057',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1113',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1433',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1538',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1580',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1789',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2136',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-463',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-491',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-797',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-841',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503706126-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503884355-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-107',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6b078a81e43d241e441f229664af52',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-420681',
      'ANILLO DE GRAFITO',
      'ANILLO DE GRAFITO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '68151099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74103-667-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74106-472-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75002-421 DRW 000 00',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7776917',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7777213',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE143 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WE288 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE259 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800T-FXJ6D4 T',
      'INTERRUPTOR',
      'INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800TC-FX6B T',
      'INTERRUPTOR',
      'INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80153-513-65',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80187-715-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '82ccae0234e1371cce27baefb184b4',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94423501',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '96183403',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '9631K236',
      'BARRA DE PLASTICO',
      'BARRA DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39169099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '99-00243',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'A165022',
      'CABLE ELECTRICO CON TERMINALES',
      'CABLE ELECTRICO CON TERMINALES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'APA40059901',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'C0070010016',
      'CUERPO PARA VALVULA',
      'CUERPO PARA VALVULA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84819099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CALIBRATION PLAT',
      'PLACA DE ALUMINIO CALIBRADA',
      'PLACA DE ALUMINIO CALIBRADA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '76169999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CONTROLADOR A2430019',
      'CONTROLADOR DE TORQUE INTELIGENTE #8436-1800-11',
      'ATLAS  #8436-1800-11 CONTROLADOR FP6000 LV   ',
      'ACT',
      'Maquinaria',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DESPERDICIO',
      'DESPERDICIO DE CARTON',
      'SCRAP',
      'PRO',
      'Producto Terminado',
      'KG',
      'KG',
      '47079001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DESPERDICIO DE COBRE',
      'DESPERDICIO DE  COBRE',
      'DESPERDICIO DE  COBRE',
      'PRO',
      NULL,
      'KG',
      'KG',
      '74040099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIN916-3X3 SCR CUP',
      'TORNILLOS DE ACERO',
      'TORNILLOS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181504',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000505297',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000664921',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6Y-158649',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'HM7130508',
      'MINI SIERRA CIRCULAR DE MANO',
      'MINI SIERRA CIRCULAR DE MANO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84672202',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'JMQD41-0002-A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-54',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-ECABLE-55',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PDOOR-19',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PDOOR-54',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PUNIT-45',
      'PROVIENE DE BOM',
      'MCC2100 Plug-in Unit',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MMC2-SP0000388 - N',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'May-29',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PLASTIC PALLETS',
      'TARIMAS PLASTICAS',
      'TARIMAS PLASTICAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-101420',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-109864',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110867',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-135989',
      'PROVIENE DE BOM',
      'PCBA, E3, 72mm,  int GF core sip, RoHs',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-146963',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-163855',
      'PROVIENE DE BOM',
      'ETO,GDI, WIRE HARN,ELA,FVNR,5-15HP,460V',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-172749',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-178241',
      'PROVIENE DE BOM',
      'LABEL,0060-05525,COUNTRY OF ORIGIN,AMAT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-179340',
      'ESTATOR PARA MOTOR',
      'ESTATOR PARA MOTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030003',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-189624',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-193355',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-201057',
      'PROVIENE DE BOM',
      '592 E300 sen mod NEMA dir mt IG 30A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-212282',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-227871-65349996',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-228569',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-23853',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-24855',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-259894',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-260259',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-262747',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-262814',
      'PROVIENE DE BOM',
      'LABEL CARD 46006-307',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-288878',
      'MODULO PROTECTOR DE CIRCUITOS',
      'ETO: Surge arrester module',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85363099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-340137',
      'PROVIENE DE BOM',
      'ETO: 6-pin connector',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-340441',
      'CONTECTOR',
      'CONTECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-344228',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-364257',
      'CONTACTOR',
      'CONTACTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-389495',
      'SERVOMOTOR DE CORRIENTE ALTERNA',
      'Kinetix VP Low Inertia Servo Motor',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-40664',
      'PROVIENE DE BOM',
      'ASSY,FUNCT,193-DNCT, SER.B',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-419005',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-420265',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-451326',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-457726',
      'INSERTO PLASTICO',
      'INSERTO PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-465131',
      'CAJA DE CONEXION',
      'ETO: 1000GM,BRAZIL ENCL,GM SAFETY CONT',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369028',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-484440',
      'ETIQUETA DE PAPEL IMPRESA',
      'ETIQUETA DE PAPEL IMPRESA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '48211001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-488616',
      'ETIQUETAS AUTOADHESIVAS DE PLASTICO',
      'ETIQUETAS AUTOADHESIVAS DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39199099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-489231',
      'CAPUCHON PARA CONECTOR',
      'CAPUCHON PARA CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-504318',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-509120',
      'MODULO',
      'MODULO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-514216',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-51955',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-532087',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-544935',
      'TRANSFORMADOR DE DISTRIBUCION',
      'TRANSFORMADOR DE DISTRIBUCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85043202',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-580358',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-596637',
      'TRANSISTORES',
      'TEMP',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85412999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-607052',
      'TRANSDUCTOR DE CORRIENTE',
      'TRANSDUCTOR DE CORRIENTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90303399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-62167',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67487-65320197',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67487-65349425',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67490-65349999',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-99959',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C157555',
      'TRANSFORMADOR ELECTRICO',
      'TRANSFORMADOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27098',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C27412',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C37046',
      'BLOQUE DE CONEXION(769-237)',
      '1-conn/1-pin ground terminal block',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C76980',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C76997-65755667',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'KG',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94936-65757635',
      'CONTROLADOR DE VELOCIDAD',
      'CONTROLADOR DE VELOCIDAD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C97545',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D165532',
      'DISTUNTOR',
      'MCB Supplementary Protector 8 A',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85362099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D166014',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D166109',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167374',
      'PROVIENE DE BOM',
      'MCCB 140G-H 65kA/480V LSI 60A 3p',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167391',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E000146',
      'PROVIENE DE BOM',
      'ETO: L1-L3 BUS BAR, REAR, 2500A BREAKER',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E005763',
      'PROVIENE DE BOM',
      'ETO: 4.5SF VERTICAL WIREWAY DOOR MOD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E013640',
      'PROVIENE DE BOM',
      'ETO:MOUNTING PLATE,20.50"X24.43"',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E015406',
      'PROVIENE DE BOM',
      'ETO: LUG PAD L3 140G N-FRAME',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E015484',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E023671',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E024790',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E033509',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E036530',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PP8050',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PRIMA-LASER-PLATINO-',
      'MAQUINA DE CORTE POR LASER',
      'MAQUINA DE CORTE POR LASER',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '84561001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'R5814-440',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SSB-HI-CAB-4',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TABLERO DE PRUEBAS',
      'TABLERO DE PRUEBAS (ID-0000002748) STF-2549',
      'TABLERO DE PRUEBAS (ID-0000002748) STF-2549 FORMADO POR : COMPUTADORA INDUSTRIAL MCA. ALLEN-BRADLEY MODELO 1450R, ANALIZADOR DIELECTRICO MARCA ASSOCIA',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '08/01/6506',
      'CARCAZA PARA SERVOMOTORES',
      'CARCAZA PARA SERVOMOTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '09/04/2341',
      'PROVIENE DE BOM',
      'XSTR,PNP,80V,0.5A,0.225W,SOT23,MMBTA56',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001675787-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001689133-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001748099-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002025491-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10002061359-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10003320180-04',
      'PASADOR DE ACERO',
      'PASADOR DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005575122-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005575124-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005682015-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005697268-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005734343-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1000A-M/A97062 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-ATDJ3-DB63X A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10523948',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10578083',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10598719',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10600775',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10610529',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10613237',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10656732',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10703899',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10703955',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '110393',
      'PANTALLA PARA PANEL',
      'PANTALLA PARA PANEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '116649',
      'PORTAFUSIBLES',
      'PORTAFUSIBLES',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-CS005B A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-HWACAB025Y A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '163',
      'MAQUINA REBOBINADORA DE CABLE 3/4          (ID-00000039665) HECHIZA',
      'MAQUINA REBOBINADORA DE CABLE 3/4          (ID-00000039665) HECHIZA',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '84798105',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1821526',
      'CUBIERTA PARA MOTOR ELECTRICO',
      'CUBIERTA PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '185557',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '194L-HE4E-175I A',
      'INTERRUPTOR DE CARGA DESENSAMBLADO',
      'INTERRUPTOR DE CARGA DESENSAMBLADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '194RC-NJ060S6 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '20D-RES-A1 A',
      'TARJETA DE CIRCUITO MODULAR',
      'TARJETA DE CIRCUITO MODULAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85049007',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '21-301-224-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '2183',
      'CAPACITOR DE TANTALIO',
      'CAPACITOR DE TANTALIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24707-092-29',
      'GENERADOR DE IMPULSOS',
      'GENERADOR DE IMPULSOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24827-106-15',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '284D-SHD6P-R5417 C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30105-884-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30116-649-02',
      'PROVIENE DE BOM',
      'ETO: VENT PLATE 5.88 IN H X 21.13 IN W',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30125-313-05',
      'VENTILA METALICA',
      'VENTILA METALICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30126-830-01',
      'PROVIENE DE BOM',
      'ETO: BRKT UPPER XFMR RITTAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30165-830-01',
      'PROVIENE DE BOM',
      'ETO: BUS UPPER LUG SQUARE D BREAKER',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30182-210-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31',
      'TABLERO  DE  PRUEBAS  SIN  DATOS  EN  GABINETE  DE  MADERA  CON: CONECTORES Y ACCESORIOS',
      'TABLERO  DE  PRUEBAS  SIN  DATOS  EN  GABINETE  DE  MADERA  CON: CONECTORES Y ACCESORIOS',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '90308999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '340357-C01',
      'SOPORTES DE PLASTICO INFERIOR',
      'SOPORTES DE PLASTICO INFERIOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '34333',
      'VENTILADOR CON FILTRO',
      'VENTILADOR CON FILTRO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84145999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '387c2edbc51371ea66e3ee6b690e7a',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '399-1268-1-ND',
      'CAPACITOR DE CERAMICA',
      'CAPACITOR DE CERAMICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '3faba9ecfd34c2f6157784fc161fe4',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-082-29',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-082-42',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40111-964-09',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-031-20',
      'PROVIENE DE BOM',
      'HORIZONTAL BUS BAR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-164-65',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40119-870-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40137-110-25',
      'PROVIENE DE BOM',
      '3.2 A FUSE LABEL 600V',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40398-310-51',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40405-474-02-2254',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40410-373-53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '405-213-00',
      'FUENTE DE PODER',
      'FUENTE DE PODER',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-364-52',
      'PROVIENE DE BOM',
      'E3 CONTROL MODULE ASSEMBL',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40798-280-54',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40891-459-05',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4201840126B113B116',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '42450-303-55',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '442L-AMBSFZNMZ1 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '46040',
      'ADHESIVO',
      'ADHESIVO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '35061001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '49710502',
      'HUSILLO PARA INSERCION DE COMPONENTES',
      'HUSILLO PARA INSERCION DE COMPONENTES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84799099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '500-FCD940 L',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-BSBJ-6P-35 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DCB-D9563 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '5160028',
      'TORNILLOS DE COBRE',
      'TORNILLOS DE COBRE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '74153399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '52002259C1-22',
      'CONECTOR ELECTRICO',
      'CONECTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '543-UFBD-R0542 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '566f1a3a59150219f3d52b6a3f8bf2',
      'MAQUINA REBOBINADORA DE CABLE 3/4 (ID-00000039665) HECHIZA',
      'MAQUINA REBOBINADORA DE CABLE 3/4 (ID-00000039665) HECHIZA',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6001922420',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '624 662 3 0 RT',
      'JUEGO DE DADOS DE CRIMPADO',
      'JUEGO DE DADOS DE CRIMPADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82079099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1023',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1165',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1223',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1379',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1380',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1528',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1703',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1840',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2065',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2135',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2186',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2193',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2245',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2250',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-353',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-656',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-696',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-837',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503762710-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503806401-100',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503953366-300',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PANEL DE CONTROL Y/O DISTRIBUCION ELECTRICA',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503973098-100',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'CENTRO DE CONTROL Y DISTRIBUCION DE ELECTRICIDAD PARA MOTORES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6503974228-125',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504059913-100',
      'TEMP',
      'TEMP',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '85371099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '68895',
      'SOPORTE DE ALUMINIO',
      'SOPORTE DE ALUMINIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '76169999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '699-0001',
      'MAQUINA DE AFILAR',
      'MAQUINA DE AFILAR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7-207899',
      'IMPULSOR',
      'IMPULSOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84139106',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74302518',
      'CILINDRO',
      'CILINDRO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84123199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75002-803 DRW 000 00',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75007-292 DRW 000 02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75046-442 DRW 000 02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7761540',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7771668',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7790208',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WT127 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WU249 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WE267 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WS243 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800FM-LF5MN5YX01 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800R-1HW4R-40979 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80300-264-65',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '888D-M5AC1-0M3B',
      'CLAVIJAS',
      'CLAVIJAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85366999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '913FK4000',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '9300160521',
      'CAJA DE PROTECCION DE ALUMINIO',
      'CAJA DE PROTECCION DE ALUMINIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '76169999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '94398086',
      'CAPACITOR MULTICAPAS',
      'CAPACITOR MULTICAPAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322499',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Bags',
      'BOLSA DE PAPEL',
      'BOLSA DE PAPEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CAJA',
      'CAJA DE CONEXION',
      'CAJA DE CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'CE TERMINATOR',
      'MAQUINA DE ACABADO',
      'MAQUINA DE ACABADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84798999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR-10001489521',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6B:4016415302',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'EA300-377',
      'MEZCLADOR PLASTICO',
      'MEZCLADOR PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MATE00630',
      'ANILLO DE SEGURIDAD CON CANDADO',
      'ANILLO DE SEGURIDAD CON CANDADO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-42',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-EBLK-12',
      'PROVIENE DE BOM',
      'MCC2100 Empty Block',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WHA-23',
      'PROVIENE DE BOM',
      'MCC2100 Wire Harness',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WHA-29',
      'PROVIENE DE BOM',
      'MCC2100 Wire Harness',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WHA-30',
      'PROVIENE DE BOM',
      'MCC2100 Wire Harness',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'N3113',
      'PUERTA DE GABINETE DE DISTRIBUCION',
      'PUERTA DE GABINETE DE DISTRIBUCION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P102510',
      'PANEL',
      'PANEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85381001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P374745',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-106123',
      'PROVIENE DE BOM',
      'S/A Light Curtain,Safe4,Trans,4 Beam 30m',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-107335',
      'PROVIENE DE BOM',
      'OXYCAST 6850FTLV RESIN, Resin Tech.Group',
      'MAT',
      'Materias Primas',
      'GRM',
      'GRM',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-107893',
      'FUSIBLE',
      'FUSIBLE',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85361099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-123364',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-135040',
      'FLECHA',
      '194R Standard Operating Shaft',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-165609',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-165926',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-173099',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-174463',
      'PROVIENE DE BOM',
      'BUL150SD,361A,690V,PWR.SEC,CT&amp;FAN ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-182902',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-184778',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-197613',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-201951',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-204490',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-211174',
      'CABLE CON CONECTORES',
      'CABLE CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-244790',
      'TINTA PARA IMPESION',
      'Ink,Digital,Yellow',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '32151999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-262808',
      'PROVIENE DE BOM',
      'LABEL CARD 46006-301',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-278105',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-279242',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-286889-65350760',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-30044',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-305282',
      'PROVIENE DE BOM',
      'ETO: Crouse-Hinds - 20way HART linking c',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-32930',
      'PROVIENE DE BOM',
      'MOD-STD - NON-REV C 120VAC',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-350635',
      'APARATO PARA MEDICION DE POTENCIA',
      'APARATO PARA MEDICION DE POTENCIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90303901',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-37487',
      'LUZ INDICADORA',
      '30mm Pilot Light 800H PB',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85318099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-389121',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'PowerFlex 700S AC Drive 20D',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-404259',
      'SUBPANEL',
      'SUBPANEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-408794',
      'CONTACTOR DE SEGURIDAD',
      'CONTACTOR DE SEGURIDAD',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-409607',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-42674',
      'PROVIENE DE BOM',
      'DRIVE HOUSING ASSY-STATUS ONLY (safety)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-430170',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-463005',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-484351',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-488787',
      'TERMINALES',
      'TERMINALES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-490104',
      'ETIQUETA ADHESIVA DE PLASTICO',
      'ETIQUETA ADHESIVA DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39199099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-503178',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-529233',
      'RELEVADOR',
      'RELEVADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85364199',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-554797',
      'PUNTAS PARA CONECTOR ELECTRICO',
      'PUNTAS PARA CONECTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85389099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-574626',
      'TERMINAL',
      'TERMINAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67487-65314297',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-67487-65333415',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-71531',
      'PROVIENE DE BOM',
      'ASM, BUL.28X, AS, DRIVE FRNT ASSY A10',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-89682',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-94866',
      'PROVIENE DE BOM',
      'VPL-A1003F,S/A,HSG-STR-EC,KE38,BRAKE',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-BT300853VPH-03',
      'SUJETADOR DE PLASTICO',
      'SUJETADOR DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C59532',
      'PLATO DE MONTAJE DE FUENTE DE PODER',
      'DIN Rail Mounting Plate',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85049099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C79789-65706476',
      'SERVOMOTOR',
      'SERVOMOTOR',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C94016',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'CONTROLADOR DE VELOCIDAD PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C95219',
      'CONTROLADOR DE VELOCIDAD PARA MOTORES ELECTRICOS',
      'PowerFlex 700 AC Drive 80 A 30 Hp 20B',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-C96149-',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D166101',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D166306',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167470',
      'PROVIENE DE BOM',
      '2100 STAB ASSY,60A,140G-J,VERT,DUAL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167567',
      'PROVIENE DE BOM',
      'L1-3 STAB&amp;WIRE,72A,140G-J,VERT,SNGL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D167596',
      'PROVIENE DE BOM',
      'L1-3 STB&amp;WIRE,180A,140G-J,HIGH,VERT,SNGL',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-D170451',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E002669',
      'PROVIENE DE BOM',
      'ETO: FRONT SUPPORT FOR ABB E2 DRAW-OUT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E014708',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E021291',
      'PLACA DE ALUMINIO',
      'ETO: NAME PLATE 3.25 X 1.00 SS SECTION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '76169999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E029551',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E036391',
      'SOPORTE METALICO',
      'SOPORTE METALICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-E038932',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'RMCF0603FT1K69DKR-ND',
      'RESISTENCIA',
      'RESISTENCIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'RMCF0805FT1K58TR-ND',
      'RESISTENCIAS',
      'RESISTENCIAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'SCB-10255',
      'TORNILLO DE ACERO',
      'TORNILLO DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181504',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'TM6-J1',
      'SENSOR FOTOSENSIBLE CON ACCESORIOS',
      'SENSOR FOTOSENSIBLE CON ACCESORIOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'VPL-063&075',
      'FRENO ELECTROMAGNETICO',
      'FRENO ELECTROMAGNETICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85052001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'X-356931',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '//',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '000000000000196466',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '000000000000311138',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '0730C-0261',
      'IMAN',
      'IMAN',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85051101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1-206062-4',
      'CONECTOR',
      'CONECTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85369099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '100',
      'DIVISOR PLASTICO',
      'DIVISOR PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90308999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10000664891 SH7',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10001696923-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10003320180-01',
      'PASADOR DE ACERO',
      'PASADOR DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10003325510',
      'PLATO ADAPTADOR PARA MOTOR ELECTRICO',
      'PLATO ADAPTADOR PARA MOTOR ELECTRICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005285809-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005652194-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656500-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005656652-D1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10005668689-1',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1000A-M/A97186 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '103S-ATDJ2-R3151 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10573814',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10582650',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10594048',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10598707',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10608131',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10641891',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10684375',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10705199',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '10709414',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '133177',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1492-ACABLE025E A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '15376',
      'PLACA METALICA INDICADORA',
      'PLACA METALICA INDICADORA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '83100099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '161493',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '16334A',
      'REPUESTOS PARA EQUIPO DE PRUEBA',
      'REPUESTOS PARA EQUIPO DE PRUEBA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90319099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '1685808',
      'CARCAZA PARA SERVOMOTOR',
      'CARCAZA PARA SERVOMOTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85030099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '177110',
      'ENSAMBLE PARA MAQUINA SOLDADORA',
      'ENSAMBLE PARA MAQUINA SOLDADORA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85159099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '18c39d5b7017dc52cdda81b876c941',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '20DC037A0EYNANANK',
      'CONTROLADOR DE VELICIDAD PARA MOTORES ELECTRICOS',
      'CONTROLADOR DE VELICIDAD PARA MOTORES ELECTRICOS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '85044013',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '23105-005-02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24707-004-15',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '24707-034-03',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '25-00446',
      'TUERCAS DE ACERO',
      'TUERCAS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181603',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '280A-F12Z-10B-CR C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '2841',
      'MEDIDOR DE RESISTENCIA',
      'MEDIDOR DE RESISTENCIA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30106-130-16',
      'PROVIENE DE BOM',
      'DIN RAIL MOD',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30110-142-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30110-665-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30156-744-01',
      'PROVIENE DE BOM',
      'C-LINK BUS LINK',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30163-954-02',
      'PROVIENE DE BOM',
      'TOP RH REAR SUPPORT',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30165-505-01',
      'PROVIENE DE BOM',
      'ETO: BUS, OFFSET SPLICE, RH,1200A',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '30169-852-01',
      'PROVIENE DE BOM',
      'ETO:  LUG PAD',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '308072',
      'MODULO DE DIODO',
      'MODULO DE DIODO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85411099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31275-137-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '31275-191-10',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '326827-Q01',
      'FILTRO DE AIRE',
      'Filter, door, paper, 650mm x 330mm x 50m',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84213999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '378459-B02',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85340099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-082-18',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40011-217-39',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40021-936-04',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40111-272-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4011149973AXXX',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40114-054-06',
      'PROVIENE DE BOM',
      '1/4 X 2 HORZ GRD BUS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40124-009-45',
      'PROVIENE DE BOM',
      'HORIZONTAL BUS BAR  MOD.',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40137-103-50',
      'PROVIENE DE BOM',
      'FUSE LABEL',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40266-550-01',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40370-205-52',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40430-302-54',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40754-477-87',
      'PROVIENE DE BOM',
      'FINAL DRIVE ASSY. - STD.',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '40755-371-67',
      'PROVIENE DE BOM',
      'PROGRAMMED ASSEMBLIES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-283-53',
      'PROVIENE DE BOM',
      'THERMAL MASS',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-452-09-B1FZ',
      'PROVIENE DE BOM',
      '317/361 AMP SMC FLEX',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '41391-820 SWR 000 04',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '43658',
      'CAPACITOR DE TANTALIO',
      'CAPACITOR DE TANTALIO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85322101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '4390151086',
      'HERRAMIENTA ELECTRICA',
      'HERRAMIENTA ELECTRICA',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '84672999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '445L-T4S1080YD',
      'TRANSMISOR',
      'TRANSMISOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85414001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '500-DOB930-91 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '505-DOB-XXX-X53',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '512-DFB-26R 1',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-AUBJ-F2929 C',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DEB-3-6XP-47 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DHB-D1220 D',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DSBD-1E-47 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '513-DUB-P0632 E',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '539668-2',
      'UTIL INTERCAMBIABLE',
      'UTIL INTERCAMBIABLE',
      'ACT',
      'Equipo',
      'PCS',
      'PCS',
      '82079099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '5504-18943195450',
      'SERVOMOTOR ELECTRICO DE CORRIENTE ALTERNA',
      'SERVOMOTOR ELECTRICO DE CORRIENTE ALTERNA',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85332101',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '58628-1',
      'PINZAS',
      'PINZAS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82032099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6001596856-1',
      'CUADROS DE MANDO OPERADOS POR BOTONES',
      'CUADROS DE MANDO OPERADOS POR BOTONES',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '61-000011-02',
      'CABLE CON CONECTORES',
      'CABLE CON CONECTORES',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1253',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1319',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-1669',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2104',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-2257',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-259',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-700',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-914',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6502722369-968',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504139784-400',
      'TEMP',
      'TEMP',
      'PRO',
      'Producto Terminado',
      'PCS',
      'KG',
      '73269099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6504339101-819',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B:1A',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '6B:3201795401',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7000360826-10',
      'REMACHE DE METAL',
      'REMACHE DE METAL',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73182399',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74106-305-56',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74159620',
      'CORREA DE TRANSMISION',
      'CORREA DE TRANSMISION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '40103201',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '74190818',
      'PIEZA AISLANTE DE PLASTICO',
      'PIEZA AISLANTE DE PLASTICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85472099',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75040-415 DRW 000 17',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '75055-421 DRW 000 01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7779432',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7789393',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7820',
      'PROBADOR DE CABLES ELECTRICOS',
      'PROBADOR DE CABLES ELECTRICOS',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '90308999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '7a8027241098a33358fe57af7bd0ea',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-11WF145 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WF165 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WG165 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800F-17WU605 A',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '800H-AR1D1P F',
      'INTERRUPTOR',
      'INTERRUPTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85365001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '80253-379-60',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '96496004',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '99-00952',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      '99-01059',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BT301094-6',
      'NUCLEO MAGNETICO',
      'NUCLEO MAGNETICO',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'BZX84-A3V6',
      'DIODOS EMISORES DE LUZ',
      'DIODOS EMISORES DE LUZ',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'C0130010054',
      'BOQUILLA DE DOSIFICACION',
      'BOQUILLA DE DOSIFICACION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '84249001',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DETAIL,NC=DS021947',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'DIR- 10000664922',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'Drawing 6_32018-064-01',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'KG',
      'KG',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'F7 DC',
      'CABLE ELECTRICO CON CONEXION',
      'CABLE ELECTRICO CON CONEXION',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '85444204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'KIT OF SCREW',
      'TORNILLOS DE ACERO',
      'TORNILLOS DE ACERO',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '73181504',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'KOR3043V',
      'EMPAQUE DE VITON',
      'EMPAQUE DE VITON',
      'MAT',
      'Materias Primas',
      'PCS',
      'KG',
      '39269002',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'LGAF-3E',
      'GRASA LUBRICANTE',
      'GRASA LUBRICANTE',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-45',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-DRMD-78',
      'PROVIENE DE BOM',
      'MCC2100 Modified Door',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-PCNT-69',
      'PROVIENE DE BOM',
      'MCC2100  Plug-in Unit Control Station',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WHA-75',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MCC2100-WRP-41',
      'PROVIENE DE BOM',
      'MCC2100 Wrap',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'MS24256R20',
      'DESINSERTADOR',
      'DESINSERTADOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '82055999',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P301200',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'P343555',
      'PROVIENE DE BOM',
      'ISSUE DO NOT PICK',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-103057',
      'PROVIENE DE BOM',
      'SMC 50, 140A 480V  MAJOR ASSEMBLY',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-104957',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110306',
      'PROVIENE DE BOM',
      'VPL-1304,ROTOR-SHAFT,STEG,(PHANTOM)',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110776',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-110945',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-112448',
      'PROVIENE DE BOM',
      'CONTROL HARDWARE,RHINO 753,FRAME 1',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-117875',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-142940',
      'PROVIENE DE BOM',
      '',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-183894',
      'PROVIENE DE BOM',
      '150-SD 24VDC CTRL 420A 480V PWR &amp;FAN ASM',
      'PRO',
      'Producto Terminado',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-200158',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-200777',
      'PROVIENE DE BOM',
      '',
      'PRO',
      'Subensamble',
      'PCS',
      'PCS',
      '0',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
INSERT INTO
    PRODUCTOS (
        P_NPARTE,
        P_DESCESP,
        P_DESCING,
        P_TIPO,
        P_TIPOPARTE,
        P_UMEDIDAPARTE,
        P_UMEDIDAFRACCION,
        P_ARANCELMX,
        P_ARANCELUS,
        P_FACTCONVERSION,
        P_NOTAS,
        P_GENDESP,
        P_GENMERMA
    ) VALUES (
      'PN-205520',
      'PARTE PARA MOTOR',
      'PARTE PARA MOTOR',
      'MAT',
      'Materias Primas',
      'PCS',
      'PCS',
      '85015204',
      NULL,
      '1.00000000',
      'Importado desde el sistema SEERT',
      'NO',
      'NO'
    );
